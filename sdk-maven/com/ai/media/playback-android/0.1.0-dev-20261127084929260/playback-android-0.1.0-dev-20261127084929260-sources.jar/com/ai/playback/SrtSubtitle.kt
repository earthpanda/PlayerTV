package com.ai.playback

import java.io.ByteArrayOutputStream
import java.io.DataOutputStream
import java.io.InputStream
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction

/** Immutable, bounded UTF-8 SubRip document. Read on IO; the caller owns/closes the stream.
 * Only plain text is supported: styling tags remain literal. No media clock or Android objects.
 */
class SrtSubtitle private constructor(internal val payload: ByteArray, val title: String) {
    companion object {
        const val MAX_BYTES = 2 * 1024 * 1024
        private const val MAX_CUES = 4096
        private const val MAX_TEXT_BYTES = 1024 * 1024
        private val timing = Regex("(\\d{2,}):([0-5]\\d):([0-5]\\d),(\\d{3})[ \\t]+-->[ \\t]+(\\d{2,}):([0-5]\\d):([0-5]\\d),(\\d{3})")
        private data class Cue(val start: Long, val end: Long, val text: ByteArray)

        /** Throws IOException for reads and IllegalArgumentException for invalid/unsupported SRT.
         * No partial document is returned. A source generation must be captured BEFORE reading.
         */
        fun read(input: InputStream, title: String): SrtSubtitle {
            require(title.isNotBlank() && title.codePointCount(0, title.length) <= 256 && title.none { it.isISOControl() }) {
                "subtitle title must contain 1..256 printable characters"
            }
            val bytes = ByteArrayOutputStream()
            val chunk = ByteArray(8192)
            while (true) {
                if (Thread.currentThread().isInterrupted) throw java.io.InterruptedIOException("subtitle read cancelled")
                val count = input.read(chunk)
                if (count < 0) break
                require(count > 0) { "subtitle stream made no progress" }
                require(bytes.size() + count <= MAX_BYTES) { "SRT exceeds 2MiB" }
                bytes.write(chunk, 0, count)
            }
            val decoded = try {
                Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes.toByteArray())).toString()
            } catch (error: java.nio.charset.CharacterCodingException) {
                throw IllegalArgumentException("SRT must be UTF-8", error)
            }
            val normalized = decoded.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n').trim('\n')
            require(normalized.isNotBlank()) { "SRT is empty" }
            require(normalized.none { it.isISOControl() && it != '\n' && it != '\t' }) { "unsupported control character" }
            val cues = mutableListOf<Cue>()
            var total = 0
            for (block in normalized.split(Regex("\n[ \\t]*\n+"))) {
                val lines = block.lines()
                require(lines.size >= 3 && lines[0].trim().toLongOrNull()?.let { it > 0 } == true) { "invalid SRT cue number" }
                val match = timing.matchEntire(lines[1].trim()) ?: throw IllegalArgumentException("invalid SRT time range")
                fun time(offset: Int): Long {
                    val hours = match.groupValues[offset].toLongOrNull() ?: throw IllegalArgumentException("SRT time overflow")
                    // Bound BEFORE multiplication; native timestamps use signed nanoseconds.
                    require(hours <= 9999) { "SRT time exceeds supported range" }
                    return ((hours * 3600 + match.groupValues[offset + 1].toLong() * 60 +
                        match.groupValues[offset + 2].toLong()) * 1000 + match.groupValues[offset + 3].toLong()) * 1_000_000
                }
                val start = time(1)
                val end = time(5)
                require(end > start) { "SRT end must follow start" }
                val text = lines.drop(2).joinToString("\n")
                require(text.isNotBlank() && text.codePointCount(0, text.length) <= 4096) { "SRT cue text exceeds limit or is empty" }
                val utf8 = text.toByteArray(Charsets.UTF_8)
                total += utf8.size
                require(total <= MAX_TEXT_BYTES && cues.size < MAX_CUES) { "SRT document exceeds cue/text budget" }
                cues += Cue(start, end, utf8)
            }
            // One visible text event is limited to 16KiB. Reject excessive overlapping
            // text before installation instead of dropping arbitrary active cues at render time.
            val boundaries = cues.flatMap { listOf(it.start to (it.text.size + 1), it.end to -(it.text.size + 1)) }
                .sortedWith(compareBy<Pair<Long, Int>> { it.first }.thenBy { it.second })
            var activeBytes = 0
            for ((_, delta) in boundaries) {
                activeBytes += delta
                require(activeBytes <= 16385) { "overlapping SRT text exceeds display budget" }
            }
            // Store in stable time order. Overlaps are retained, rather than silently losing text.
            val wire = ByteArrayOutputStream()
            DataOutputStream(wire).use { out ->
                out.writeInt(cues.size)
                for (cue in cues.sortedBy { it.start }) {
                    out.writeLong(cue.start); out.writeLong(cue.end)
                    out.writeInt(cue.text.size); out.write(cue.text)
                }
            }
            return SrtSubtitle(wire.toByteArray(), title)
        }
    }
}
