package com.ai.playback

/** A current-source audio stream. Keep generation with index; never reuse across load/stop. */
data class AudioTrack(
    val generation: Long,
    val index: Int,
    val title: String = "",
    val language: String = "",
    val codec: String = "",
)

/** Admission is distinct from the native selector acknowledgment. No audible-output claim. */
data class AudioTrackChange(val id: Long, val index: Int)
