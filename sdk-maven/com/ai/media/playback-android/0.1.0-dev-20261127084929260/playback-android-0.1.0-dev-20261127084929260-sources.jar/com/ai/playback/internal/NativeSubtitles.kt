package com.ai.playback.internal

import com.ai.playback.SubtitleCue
import com.ai.playback.SubtitleTrack
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.Base64

internal object NativeSubtitles {
    internal sealed interface PositionNoticeChange {
        data object Clear : PositionNoticeChange
        data class Unconfirmed(val trackIndex: Int, val framePositionNs: Long) : PositionNoticeChange
    }

    /** Reject older timeline/track events before they reach the public notice flow. */
    fun positionNoticeChange(wire: String, epoch: Long, selection: Long, selectedTrack: Int?,
        status: Long, framePositionNs: Long): PositionNoticeChange? {
        if (wire.length > 64 || epoch < 0 || selection < 0 || selectedTrack == null || selectedTrack !in 0..63) return null
        val fields = wire.split('\t')
        if (fields.size != 3 || fields[0].toLongOrNull() != epoch ||
            fields[1].toLongOrNull() != selection || fields[2].toIntOrNull() != selectedTrack) return null
        return when {
            status == 0L && framePositionNs >= -1L -> PositionNoticeChange.Clear
            status == 1L && framePositionNs >= 0L -> PositionNoticeChange.Unconfirmed(selectedTrack, framePositionNs)
            else -> null
        }
    }

    /** Only the currently admitted timeline and subtitle selection may update the cue. */
    fun currentCuePayload(wire: String, epoch: Long, selection: Long): String? {
        if (wire.length > 21900 || epoch < 0 || selection < 0) return null
        val first = wire.indexOf('\t')
        if (first <= 0) return null
        val second = wire.indexOf('\t', first + 1)
        if (second <= first + 1) return null
        if (wire.substring(0, first).toLongOrNull() != epoch ||
            wire.substring(first + 1, second).toLongOrNull() != selection) return null
        return wire.substring(second + 1).takeIf { it.length <= 21848 }
    }

    fun tracks(generation: Long, wire: String): List<SubtitleTrack>? {
        if (wire.length > 275_000) return null
        val rows = wire.split('\n')
        val last = rows.last().split('\t')
        val external = last.size == 5 && last[0] == "64" && last[4] == "external"
        val embedded = if (external) rows.dropLast(1).joinToString("\n") else wire
        val tracks = NativeAudioTracks.decode(generation, embedded)?.map {
            SubtitleTrack(it.generation, it.index, it.title, it.language, it.codec)
        } ?: return null
        if (!external) return tracks
        val item = NativeAudioTracks.decode(generation, "0\t" + last.subList(1, 4).joinToString("\t"))?.singleOrNull() ?: return null
        return tracks + SubtitleTrack(generation, 64, item.title, item.language, item.codec, external = true)
    }

    fun cue(startNs: Long, endNs: Long, wire: String): SubtitleCue? {
        if (startNs < 0 || endNs <= startNs || wire.isEmpty() || wire.length > 21848) return null
        return try {
            val bytes = Base64.getDecoder().decode(wire)
            if (bytes.size > 16384) return null
            val text = Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString()
            if (text.isEmpty() || text.any { it.isISOControl() && it != '\n' && it != '\t' }) null
            else SubtitleCue(text, startNs, endNs)
        } catch (_: IllegalArgumentException) { null }
        catch (_: java.nio.charset.CharacterCodingException) { null }
    }
}
