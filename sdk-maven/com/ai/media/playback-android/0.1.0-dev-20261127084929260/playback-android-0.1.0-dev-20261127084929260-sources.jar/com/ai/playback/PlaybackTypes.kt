package com.ai.playback

/** How video decoders are admitted. AUTO follows GStreamer's hardware-first Android ranks. */
enum class DecoderMode { AUTO, HARDWARE_ONLY, SOFTWARE_ONLY }

/** GRAYSCALE uses a GLES texture shader, without CPU pixel readback or CPU-filter fallback.
 * HARDWARE_ONLY requires GLMemory decoder output; AUTO may upload software frames.
 * load selects the initial effect; setVideoEffect changes it at the next frame without reload.
 * HDR tone mapping is not provided by this SDR effect.
 */
enum class VideoEffect { NONE, GRAYSCALE }

/** FAST lands on a keyframe. ACCURATE decodes/discards until the requested media time. */
enum class SeekMode { FAST, ACCURATE }

enum class PlaybackPhase { IDLE, PREPARING, PLAYING, PAUSED, BUFFERING, ENDED, FAILED, RELEASING, RELEASED }

/** COMPLETE acknowledges a new sink preroll, not physical display scanout. */
enum class FrameStepStatus { IDLE, STEPPING, COMPLETE, END_OF_MEDIA }

enum class ScrubStatus { DRAGGING, SETTLING, COMPLETE, TIMED_OUT }

/** Latest requested position is distinct from the actual sink preroll media time.
 * id isolates consecutive gestures in one source; COMPLETE is not physical display scanout.
 */
data class VideoScrub(
    val id: Long,
    val status: ScrubStatus,
    val requestedPositionMs: Long,
    val framePositionNs: Long? = null,
) {
    val active: Boolean get() = status == ScrubStatus.DRAGGING || status == ScrubStatus.SETTLING
}

/** Stable technical categories. UI owns user-facing text; diagnostic does not contain source URLs. */
enum class PlaybackErrorCode {
    SOURCE_IO, UNSUPPORTED_MEDIA, DECODE_FAILED, OUTPUT_FAILED, PIPELINE_FAILED,
    COMMAND_REJECTED, SEEK_UNAVAILABLE, RATE_UNAVAILABLE, FOCUS_DENIED, INVALID_INPUT,
    LOOP_UNAVAILABLE,
    STEP_UNAVAILABLE,
    SCRUB_UNAVAILABLE,
    AUDIO_TRACK_UNAVAILABLE,
    SUBTITLE_UNAVAILABLE,
    SCRUB_TIMEOUT,
    /** The server supplied a different version during this session; reopen the source. */
    SOURCE_CHANGED,
    /** The HTTP server did not honor a seek request. Reload explicitly to retry from the start. */
    SOURCE_SEEK_UNSUPPORTED,
}

data class PlaybackFailure(val code: PlaybackErrorCode, val diagnostic: String)

/** Confirmed continuous audio/video data already received by the current network pipeline.
 * This conservative range may omit additional buffered data; it is not a reusable seek cache.
 * Positions are media milliseconds. Null from AndroidPlayer.bufferedRange means unknown.
 */
data class PlaybackBufferedRange(val generation: Long, val startPositionMs: Long, val endPositionMs: Long)

sealed interface CommandResult {
    data object Accepted : CommandResult
    data class Rejected(val failure: PlaybackFailure) : CommandResult
}

/** All positions are milliseconds. Options are applied to a new load, never by mutating global ranks. */
data class PlaybackOptions(
    val decoderMode: DecoderMode = DecoderMode.AUTO,
    val videoEffect: VideoEffect = VideoEffect.NONE,
    val playWhenReady: Boolean = true,
    val startPositionMs: Long = 0,
) {
    init { require(startPositionMs >= 0) }
}

data class DecoderInfo(val factory: String, val hardware: Boolean, val video: Boolean)

/** Immutable, conflated snapshots. A test source has no compressed-video decoder to report. */
data class PlaybackSnapshot(
    val generation: Long = 0,
    val phase: PlaybackPhase = PlaybackPhase.IDLE,
    val positionMs: Long = 0,
    val durationMs: Long? = null,
    val seekable: Boolean = false,
    val bufferedPercent: Int = 100,
    val speed: Double = 1.0,
    val decoders: List<DecoderInfo> = emptyList(),
    val processedVideoFrames: Long = 0,
    val droppedVideoFrames: Long = 0,
    val failure: PlaybackFailure? = null,
    /** Acknowledged native parameter; a paused frame is not repainted until another video frame. */
    val videoEffect: VideoEffect = VideoEffect.NONE,
    val volume: Double = 1.0,
    val muted: Boolean = false,
    val mediaInfo: MediaInfo? = null,
    /** Native-acknowledged current-source loop. Seek exits A–B; stop/load/detach clear both modes. */
    val loop: PlaybackLoop? = null,
    val frameStep: FrameStepStatus = FrameStepStatus.IDLE,
    /** Actual output video buffer's media time in ns (PTS mapped through its segment). */
    val framePositionNs: Long? = null,
    val scrub: VideoScrub? = null,
    val audioTracks: List<AudioTrack> = emptyList(),
    /** Actual combiner selection; pendingAudioTrack separately waits for the output boundary. */
    val selectedAudioTrackIndex: Int? = null,
    val pendingAudioTrack: AudioTrackChange? = null,
    val subtitleTracks: List<SubtitleTrack> = emptyList(),
    val selectedSubtitleTrackIndex: Int? = null,
    val pendingSubtitleTrack: SubtitleTrackChange? = null,
    val subtitleCue: SubtitleCue? = null,
)
