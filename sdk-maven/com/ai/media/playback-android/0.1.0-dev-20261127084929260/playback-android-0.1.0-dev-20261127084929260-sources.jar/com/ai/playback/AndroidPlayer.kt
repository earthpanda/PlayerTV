package com.ai.playback

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.security.NetworkSecurityPolicy
import android.view.Surface
import com.ai.playback.internal.NativeRuntime
import com.ai.playback.internal.NativeSession
import com.ai.playback.internal.NetworkMediaUri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * A page-owned Android player. Create is suspending; all commands/close are main-thread only.
 * Descriptor ownership stays with the caller: native duplicates it before load returns.
 * Surface ownership stays with its host. close is nonblocking; awaitReleased confirms teardown.
 */
class AndroidPlayer private constructor(context: Context) : AutoCloseable {
    private val native = NativeSession()
    val state = native.state
    /** Confirmed network media coverage; null for unknown or unsupported sources. */
    val bufferedRange = native.bufferedRange
    /** Nonfatal notice for an unconfirmed current embedded subtitle; null when no notice is active. */
    val subtitlePositionNotice = native.subtitlePositionNotice
    /** Current source's session cache state; null when no session cache is requested or after stop. */
    val sessionCacheStatus = native.sessionCacheStatus
    /** Confirmed reusable session-cache intervals, or null when unavailable or not yet known.
     * Only supported sources can yield ranges; an empty list does not prove uncached data is absent.
     * Intervals may be withdrawn after eviction or invalidation and are not an offline-playback guarantee.
     * Observe on any thread; load/stop/close commands remain main-thread only.
     */
    val sessionCacheRanges = native.sessionCacheRanges
    private val cacheDirectory by lazy(LazyThreadSafetyMode.NONE) { context.applicationContext.cacheDir.absolutePath }

    /** Records actual final GPU frames and audible PCM on one real-time timeline. Main only.
     * Await started, update host composition as needed, then finish/cancel and close your output.
     * The source is not decoded again; rate, effects, mute and loop changes are captured live.
     */
    fun startRecording(output: ParcelFileDescriptor, options: RecordingOptions = RecordingOptions()): PlaybackRecording {
        checkMain()
        if (closed) throw RecordingException("player closed")
        return native.startRecording(output, options)
    }

    /** Installs/replaces the sole external SRT and selects it, without seeking/reloading A/V.
     * Capture generation before reading on IO. Native acknowledgment confirms installation.
     */
    fun addSubtitle(document: SrtSubtitle, generation: Long): CommandResult {
        checkMain()
        if (closed) return invalid("player closed")
        return native.addSubtitle(document, generation)
    }
    private val audio = context.applicationContext.getSystemService(AudioManager::class.java)
    private var closed = false
    private var hasFocus = false
    private var focusRequestActive = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val focusRequest = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN)
        .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA)
            .setContentType(AudioAttributes.CONTENT_TYPE_MOVIE).build())
        .setOnAudioFocusChangeListener({ change ->
            if (!closed && change != AudioManager.AUDIOFOCUS_GAIN) {
                // This profile never resumes on a later focus gain. Remove the request as well
                // as pausing, so a stopped session cannot keep a registered focus listener.
                abandonFocus()
                native.command(NativeSession.PAUSE)
            }
        }, Handler(Looper.getMainLooper()))
        .build()

    init {
        scope.launch {
            state.collect { snapshot ->
                if (snapshot.phase in setOf(PlaybackPhase.IDLE, PlaybackPhase.ENDED, PlaybackPhase.FAILED)) abandonFocus()
            }
        }
    }

    fun load(descriptor: ParcelFileDescriptor, options: PlaybackOptions = PlaybackOptions()): CommandResult {
        checkMain()
        if (closed) return invalid("player closed")
        return submitLoad(options) { native.load(descriptor, null, false, options) }
    }

    /** Compatibility HTTPS-only entry. Direct media URL; no redirects, credentials or automatic retry. */
    fun loadHttps(uri: String, options: PlaybackOptions = PlaybackOptions()): CommandResult {
        checkMain()
        if (!NetworkMediaUri.allowed(uri, httpsOnly = true) { false }) return invalid("direct HTTPS media URI required")
        if (closed) return invalid("player closed")
        return submitLoad(options) { native.load(null, uri, false, options) }
    }

    /** HTTP(S) direct media URL. HTTP requires the host's per-domain Network Security Config.
     * Uses the existing bounded native source; Accepted is not a prepared/playback acknowledgment.
     * No redirects, URL credentials, cookies, automatic retries, caching or background downloads.
     * TLS uses the SDK CA bundle; host Android custom trust anchors are not imported into GIO.
     */
    fun loadNetwork(uri: String, options: PlaybackOptions = PlaybackOptions()): CommandResult {
        checkMain()
        if (!NetworkMediaUri.allowed(uri, httpsOnly = false) {
                NetworkSecurityPolicy.getInstance().isCleartextTrafficPermitted(it)
            }) return invalid("direct HTTP(S) media URI required; cleartext must be permitted by host")
        if (closed) return invalid("player closed")
        return submitLoad(options) { native.load(null, uri, false, options) }
    }

    /** Direct HTTP(S) source with a temporary, bounded cache for this playback session.
     * Cached data is discarded on stop, load or close. The effective budget is capped at
     * 512 MiB and may be smaller than capacityBytes when storage is limited.
     * Observe sessionCacheStatus and state.failure;
     * ATTACHED means the store opened, not that a media range is ready to play.
     */
    @JvmOverloads
    fun loadNetworkWithSessionCache(uri: String, options: PlaybackOptions = PlaybackOptions(),
        capacityBytes: Long = 512L * 1024 * 1024): CommandResult {
        checkMain()
        if (!NetworkMediaUri.allowed(uri, httpsOnly = false) {
                NetworkSecurityPolicy.getInstance().isCleartextTrafficPermitted(it)
            }) return invalid("direct HTTP(S) media URI required; cleartext must be permitted by host")
        if (capacityBytes < 2L * 1024 * 1024 || capacityBytes > 2L * 1024 * 1024 * 1024)
            return invalid("session cache capacity must be between 2 MiB and 2 GiB")
        if (closed) return invalid("player closed")
        val directory = try { cacheDirectory } catch (_: Exception) {
            return invalid("session cache directory unavailable")
        }
        return submitLoad(options) { native.loadWithSessionCache(uri, options, directory, capacityBytes) }
    }

    /** Live diagnostic pattern and quiet sine tone. Exercises output/filtering, not compressed decoding. */
    fun loadTestPattern(options: PlaybackOptions = PlaybackOptions()): CommandResult {
        checkMain()
        if (closed) return invalid("player closed")
        return submitLoad(options) { native.load(null, null, true, options) }
    }

    fun play(): CommandResult {
        checkMain()
        if (closed) return invalid("player closed")
        if (state.value.phase !in setOf(PlaybackPhase.PREPARING, PlaybackPhase.PLAYING,
                PlaybackPhase.PAUSED, PlaybackPhase.BUFFERING)) {
            return CommandResult.Rejected(PlaybackFailure(PlaybackErrorCode.COMMAND_REJECTED, "load media before play"))
        }
        val alreadyHeld = hasFocus
        if (!focus()) return focusDenied()
        return native.command(NativeSession.PLAY).also {
            if (it is CommandResult.Rejected && !alreadyHeld) abandonFocus()
        }
    }

    fun pause(): CommandResult {
        checkMain()
        return native.command(NativeSession.PAUSE).also {
            if (it is CommandResult.Accepted) abandonFocus()
        }
    }

    /** Advances one decoded video frame while PAUSED, without playing audio or seeking by time.
     * Only one request may be pending. Observe state.frameStep/framePositionNs for completion.
     * Loop mode is retained; without a loop the final picture stays visible at END_OF_MEDIA.
     * Play/seek/rate/loop reconfiguration are rejected while stepping; stop/load/close can cancel.
     */
    fun stepForward(): CommandResult {
        checkMain()
        if (closed) return invalid("player closed")
        val snapshot = state.value
        if (snapshot.phase != PlaybackPhase.PAUSED || !snapshot.seekable ||
            snapshot.frameStep in setOf(FrameStepStatus.STEPPING, FrameStepStatus.END_OF_MEDIA))
            return CommandResult.Rejected(PlaybackFailure(PlaybackErrorCode.STEP_UNAVAILABLE,
                "pause a prepared seekable video before stepping"))
        return native.command(NativeSession.STEP)
    }

    /** Stops and releases the loaded pipeline; a subsequent load is required to play again. */
    fun stop(): CommandResult {
        checkMain()
        abandonFocus()
        return native.command(NativeSession.STOP)
    }

    @JvmOverloads
    fun seekTo(positionMs: Long, mode: SeekMode = SeekMode.FAST): CommandResult {
        checkMain()
        if (positionMs < 0) return invalid("negative position")
        return native.command(NativeSession.SEEK, positionMs, mode.ordinal.toDouble())
    }

    /** Starts silent main-picture preview using the current decoder/Surface. Native retains the
     * current play intent; focus loss or pause prevents automatic resume. Requires prepared,
     * seekable non-live video with known duration. Observe state.scrub for native completion.
     */
    fun beginScrub(): CommandResult {
        checkMain()
        if (closed) return invalid("player closed")
        val current = state.value
        if (!current.seekable || (current.durationMs ?: 0) <= 0 || (current.mediaInfo?.videoStreamCount ?: 0) <= 0 ||
            current.phase !in setOf(PlaybackPhase.PLAYING, PlaybackPhase.PAUSED, PlaybackPhase.BUFFERING) ||
            current.frameStep == FrameStepStatus.STEPPING)
            return CommandResult.Rejected(PlaybackFailure(PlaybackErrorCode.SCRUB_UNAVAILABLE,
                "scrub requires prepared seekable video"))
        return native.beginScrub()
    }

    /** Replaces obsolete preview work. The latest target waits for a frame or a source error. */
    fun scrubTo(positionMs: Long): CommandResult {
        checkMain()
        if (positionMs < 0) return invalid("negative position")
        return native.updateScrub(positionMs, final = false)
    }

    /** Always commits a final ACCURATE seek, then resumes only if play intent is still valid. */
    fun endScrub(positionMs: Long): CommandResult {
        checkMain()
        if (positionMs < 0) return invalid("negative position")
        return native.updateScrub(positionMs, final = true)
    }

    /** Discards pending targets, settles an in-flight seek and stays paused. */
    fun cancelScrub(): CommandResult {
        checkMain()
        return native.cancelScrub().also { if (it is CommandResult.Accepted) abandonFocus() }
    }

    /** Starts at A, preserving play/pause and speed. Null resumes the full source at its current
     * queried position. Explicit seek exits A–B but retains whole-video mode; stop, load and
     * actual Surface replacement clear either mode.
     * Accepted means queued; state.loop acknowledges native acceptance, not physical presentation.
     */
    fun setLoop(interval: PlaybackLoop?): CommandResult {
        checkMain()
        if (interval?.wholeVideo == true) return setVideoLoop(true)
        return native.command(NativeSession.LOOP, interval?.startMs ?: -1,
            endMs = interval?.endMs ?: -1)
    }

    /** Repeat the whole current video. Enabling keeps the current playhead; subsequent cycles
     * start at zero. Explicit seeks retain this mode; stop/load/Surface replacement clear it.
     */
    fun setVideoLoop(enabled: Boolean): CommandResult {
        checkMain()
        return if (enabled) native.command(NativeSession.LOOP, 0, scalar = 1.0)
        else setLoop(null)
    }

    /** Per-player gain. Does not change Android's media volume; retained across stop/load. */
    fun setVolume(volume: Double): CommandResult {
        checkMain()
        if (!volume.isFinite() || volume !in 0.0..1.0) return invalid("volume must be between 0 and 1")
        return native.command(NativeSession.VOLUME, scalar = volume)
    }

    /** Independent of gain: unmuting restores the selected gain, never an invented full volume. */
    fun setMuted(muted: Boolean): CommandResult {
        checkMain()
        return native.command(NativeSession.MUTE, if (muted) 1 else 0)
    }

    /** Selects a track obtained from the current snapshot. Accepted is queued; observe
     * pendingAudioTrack for output-boundary completion; selectedAudioTrackIndex is the combiner value.
     * Discards old queued audio; preserves play intent, volume/mute, speed, loop and video clock.
     * Confirmation is not a guarantee of physical speaker output or gapless switching.
     * Paused decoders can defer confirmation until play(); selection never forces playback.
     */
    fun selectAudioTrack(track: AudioTrack): CommandResult {
        checkMain()
        if (closed) return invalid("player closed")
        return native.selectAudio(track)
    }

    /** Select embedded text from the current snapshot, or null to disable (default).
     * Observe pendingSubtitleTrack/selectedSubtitleTrackIndex and render subtitleCue as plain text.
     * No reload/seek/video mapping. A paused stream switch may await resume; never forces play.
     */
    fun selectSubtitleTrack(track: SubtitleTrack?): CommandResult {
        checkMain()
        if (closed) return invalid("player closed")
        return native.selectSubtitle(track)
    }

    fun setSpeed(speed: Double): CommandResult {
        checkMain()
        if (!speed.isFinite() || speed !in 0.5..2.0) return invalid("speed must be between 0.5 and 2.0")
        return native.command(NativeSession.RATE, scalar = speed)
    }

    fun setSurface(surface: Surface?): CommandResult {
        checkMain()
        return native.surface(surface)
    }

    /** Updates a prepared GPU parameter without reload/seek. Visible on the next video frame.
     * A paused pipeline keeps its last displayed frame until playback produces another frame.
     */
    fun setVideoEffect(effect: VideoEffect): CommandResult {
        checkMain()
        if (closed) return invalid("player closed")
        if (state.value.phase !in setOf(PlaybackPhase.PREPARING, PlaybackPhase.PLAYING,
                PlaybackPhase.PAUSED, PlaybackPhase.BUFFERING)) {
            return CommandResult.Rejected(PlaybackFailure(PlaybackErrorCode.COMMAND_REJECTED, "load media before changing video effect"))
        }
        return native.command(NativeSession.EFFECT, effect.ordinal.toLong())
    }

    override fun close() {
        checkMain()
        if (closed) return
        closed = true
        abandonFocus()
        native.close()
        scope.cancel()
    }

    suspend fun awaitReleased() = native.awaitReleased()

    /** Main-thread suspend request for the latest displayed post-filter frame and actual media time.
     * One at a time; max 32MiB RGBA. Does not pause/seek/reload or capture UI/subtitles/crop.
     * Convert/encode on a worker. Cancellation, stop/load/Surface replacement/close invalidate it.
     * Throws FrameCaptureException for unavailable/busy/unsupported readback, without failing playback.
     */
    suspend fun captureFrame(): VideoFrame {
        checkMain()
        if (closed) throw FrameCaptureException(FrameCaptureError.NO_FRAME)
        return native.captureFrame()
    }

    private inline fun submitLoad(options: PlaybackOptions, submit: () -> CommandResult): CommandResult {
        val alreadyHeld = hasFocus
        if (options.playWhenReady && !focus()) return focusDenied()
        val result = submit()
        if ((result is CommandResult.Accepted && !options.playWhenReady) ||
            (result is CommandResult.Rejected && !alreadyHeld)) abandonFocus()
        return result
    }

    private fun focus(): Boolean {
        if (hasFocus) return true
        hasFocus = audio.requestAudioFocus(focusRequest) == AudioManager.AUDIOFOCUS_REQUEST_GRANTED
        focusRequestActive = hasFocus
        return hasFocus
    }

    private fun abandonFocus() {
        if (focusRequestActive) audio.abandonAudioFocusRequest(focusRequest)
        focusRequestActive = false
        hasFocus = false
    }

    private fun checkMain() = check(Looper.myLooper() == Looper.getMainLooper()) { "Playback commands require the main thread" }
    private fun invalid(detail: String) = CommandResult.Rejected(PlaybackFailure(PlaybackErrorCode.INVALID_INPUT, detail))
    private fun focusDenied() = CommandResult.Rejected(PlaybackFailure(PlaybackErrorCode.FOCUS_DENIED, "audio focus denied"))

    companion object {
        /** Loads and initializes native libraries on IO; no activity, autoplay or global player is retained. */
        suspend fun create(context: Context): AndroidPlayer {
            NativeRuntime.initialize(context.applicationContext)
            var created: AndroidPlayer? = null
            try {
                return withContext(Dispatchers.Main.immediate) {
                    AndroidPlayer(context.applicationContext).also { created = it }
                }
            } catch (cancelled: CancellationException) {
                withContext(NonCancellable + Dispatchers.Main.immediate) { created?.close() }
                throw cancelled
            }
        }
    }
}
