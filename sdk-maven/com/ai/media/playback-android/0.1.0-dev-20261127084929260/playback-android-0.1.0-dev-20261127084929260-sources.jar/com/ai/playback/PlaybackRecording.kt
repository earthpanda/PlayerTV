package com.ai.playback

import android.graphics.Bitmap
import android.os.Looper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.nio.ByteBuffer

/** Fixed video-area canvas; no controls/system bars. Time is real elapsed playback, including pauses.
 * H264 hardware Surface encoding, SDR, up to 1920 on either axis; audio is final PCM → AAC stereo.
 * Recording is page-owned. Finish publishes nothing by itself; the host owns the destination file.
 */
data class RecordingOptions(val width: Int = 1280, val height: Int = 720) {
    init { require(width in 16..1920 && height in 16..1920 && width % 2 == 0 && height % 2 == 0) }
}
enum class RecordingPhase { PREPARING, RECORDING, FINISHING, COMPLETE, CANCELLED, FAILED }
data class RecordingSnapshot(val phase: RecordingPhase = RecordingPhase.PREPARING, val durationMs: Long = 0,
    val videoFrames: Long = 0, val diagnostic: String = "") {
    val finished: Boolean get() = phase in setOf(RecordingPhase.COMPLETE, RecordingPhase.CANCELLED, RecordingPhase.FAILED)
}
data class RecordingResult(val width: Int, val height: Int, val durationMs: Long, val videoFrames: Long)
class RecordingException(message: String) : Exception(message)

/** Main-thread controls. The private monitor polls a small status value at 10Hz, never video/PCM.
 * Native owns finite queues and a confined EGL/codec/muxer worker. finish/cancel await its cleanup.
 * load/stop/close or a real Surface change cancel recording without publishing a partial MP4.
 */
class PlaybackRecording internal constructor(private var lease: Long, val options: RecordingOptions,
    private val requestStop: (Long, Boolean) -> Boolean) {
    private val mutableState = MutableStateFlow(RecordingSnapshot())
    val state = mutableState.asStateFlow()
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var stopSent = false
    private var crop = false
    private var overlayPixels: ByteBuffer? = null // One reusable, bounded text upload buffer.
    init {
        scope.launch {
            try {
                while (true) {
                    val values = nativePoll(lease).split('\t', limit = 6)
                    val snapshot = RecordingSnapshot(RecordingPhase.entries[values[0].toInt()],
                        values[1].toLong(), values[4].toLong(), values.getOrElse(5) { "" })
                    if (snapshot.finished) {
                        nativeDispose(lease); lease = 0; overlayPixels = null
                        mutableState.value = snapshot
                        break
                    }
                    mutableState.value = snapshot
                    delay(100)
                }
            } finally { scope.cancel() }
        }
    }
    suspend fun awaitStarted() {
        checkMain()
        val current = state.first { it.phase != RecordingPhase.PREPARING }
        if (current.phase != RecordingPhase.RECORDING) throw RecordingException(current.diagnostic.ifEmpty { "recording did not start" })
    }
    /** Apply the host's video-area geometry and optional transparent overlay. Bitmap is copied now,
     * not retained; only upload again when text/layout changes. This is not CPU video readback.
     * Match the canvas aspect ratio. Null clears subtitles. Premultiplied ARGB_8888 required.
     */
    @JvmOverloads
    fun setComposition(cropToFill: Boolean, overlay: Bitmap?, viewportWidth: Int = options.width,
        viewportHeight: Int = options.height) {
        checkMain(); if (lease == 0L || stopSent) return
        crop = cropToFill
        require(overlay == null || (overlay.config == Bitmap.Config.ARGB_8888 && overlay.width <= 1920 && overlay.height <= 1920 &&
            overlay.rowBytes == overlay.width * 4 && overlay.isPremultiplied))
        val pixels = overlay?.let { bitmap ->
            val buffer = overlayPixels?.takeIf { it.capacity() >= bitmap.byteCount }
                ?: ByteBuffer.allocateDirect(bitmap.byteCount).also { overlayPixels = it }
            buffer.clear(); bitmap.copyPixelsToBuffer(buffer); buffer
        }
        require(viewportWidth > 0 && viewportHeight > 0)
        nativeComposition(lease, crop, pixels, overlay?.width ?: 0, overlay?.height ?: 0,
            viewportWidth.toDouble()/viewportHeight)
    }
    fun setCropToFill(enabled: Boolean) {
        checkMain(); if (lease == 0L || stopSent) return
        crop = enabled; nativeComposition(lease, crop, null, -1, -1, 0.0)
    }
    suspend fun finish(): RecordingResult {
        checkMain(); stop(false)
        val result = state.first { it.finished }
        if (result.phase != RecordingPhase.COMPLETE) throw RecordingException(result.diagnostic.ifEmpty { "recording cancelled" })
        return RecordingResult(options.width, options.height, result.durationMs, result.videoFrames)
    }
    suspend fun cancel() = withContext(NonCancellable + Dispatchers.Main.immediate) {
        stop(true); state.first { it.finished }; Unit
    }
    private fun stop(cancel: Boolean) {
        if (lease == 0L) return
        if (!stopSent || cancel) {
            stopSent = true
            if (!requestStop(lease, cancel)) nativeStop(lease, true)
        }
    }
    private fun checkMain() = check(Looper.myLooper() == Looper.getMainLooper()) { "Recording controls require Main" }
    private external fun nativePoll(lease: Long): String
    private external fun nativeStop(lease: Long, cancel: Boolean)
    private external fun nativeDispose(lease: Long)
    private external fun nativeComposition(lease: Long, crop: Boolean, rgba: ByteBuffer?, width: Int, height: Int, viewportAspect: Double)
}
