package com.ai.playback.internal

import com.ai.playback.AudioTrack
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import java.util.Base64

/** Bounded ASCII wire with UTF-8 tags. Reject malformed catalogs instead of partial selections. */
internal object NativeAudioTracks {
    fun decode(generation: Long, wire: String): List<AudioTrack>? {
        if (wire.isEmpty()) return emptyList()
        if (wire.length > 270_000) return null
        val lines = wire.split('\n')
        if (lines.size > 64) return null
        return try {
            lines.mapIndexed { index, line ->
                val fields = line.split('\t')
                if (fields.size != 4 || fields[0].toIntOrNull() != index) return null
                fun text(value: String): String {
                    require(value.length <= 1368)
                    val decoded = Charsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                        .onUnmappableCharacter(CodingErrorAction.REPORT)
                        .decode(ByteBuffer.wrap(Base64.getDecoder().decode(value))).toString()
                    require(decoded.codePointCount(0, decoded.length) <= 256)
                    require(decoded.none { it.isISOControl() })
                    return decoded
                }
                AudioTrack(generation, index, text(fields[1]), text(fields[2]), text(fields[3]))
            }
        } catch (_: IllegalArgumentException) { null }
        catch (_: java.nio.charset.CharacterCodingException) { null }
    }
}
