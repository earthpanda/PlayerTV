package com.ai.playback.internal

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.freedesktop.gstreamer.GStreamer

/** Process-wide GStreamer registry initialization only; owns no player, page or running task. */
internal object NativeRuntime {
    private val mutex = Mutex()
    private var initialized = false

    suspend fun initialize(context: Context) = withContext(Dispatchers.IO) {
        mutex.withLock {
            if (!initialized) {
                System.loadLibrary("gstreamer_android")
                System.loadLibrary("playback_native")
                GStreamer.init(context.applicationContext)
                initialized = true
            }
        }
    }
}
