package com.ai.playback.internal

import com.ai.playback.DecoderInfo
import com.ai.playback.PlaybackErrorCode
import com.ai.playback.PlaybackFailure
import com.ai.playback.PlaybackPhase
import com.ai.playback.PlaybackSnapshot
import com.ai.playback.PlaybackLoop
import com.ai.playback.VideoEffect
import com.ai.playback.FrameStepStatus
import com.ai.playback.ScrubStatus

/** Pure callback boundary: stale media cannot overwrite the current source or resurrect teardown. */
internal object NativeEvents {
    fun reduce(old: PlaybackSnapshot, generation: Long, event: Int, first: Long, second: Long, detail: String,
        expectedScrubRevision: Long = 0): PlaybackSnapshot {
        if (event == 10) return old.copy(phase = PlaybackPhase.RELEASED, seekable = false, loop = null,
            subtitleTracks = emptyList(), selectedSubtitleTrackIndex = null, pendingSubtitleTrack = null, subtitleCue = null,
            frameStep = FrameStepStatus.IDLE, framePositionNs = null, scrub = null,
            audioTracks = emptyList(), selectedAudioTrackIndex = null, pendingAudioTrack = null)
        if (generation != old.generation || old.phase in setOf(PlaybackPhase.RELEASING, PlaybackPhase.RELEASED)) return old
        // A command already queued when a terminal failure tears down the
        // graph can be rejected afterwards. Keep the terminal cause visible.
        if (event == 9 && old.phase == PlaybackPhase.FAILED) return old
        return when (event) {
            1 -> if (first == 0L) PlaybackSnapshot(generation = old.generation, volume = old.volume, muted = old.muted) else
                PlaybackPhase.entries.getOrNull(first.toInt())?.let {
                    old.copy(phase = it,
                        failure = old.failure?.takeIf { failure -> failure.code == PlaybackErrorCode.SCRUB_TIMEOUT &&
                            old.scrub?.status == ScrubStatus.TIMED_OUT && it != PlaybackPhase.ENDED },
                        seekable = old.seekable && it != PlaybackPhase.ENDED,
                        frameStep = if (it == PlaybackPhase.PAUSED) old.frameStep else FrameStepStatus.IDLE,
                        framePositionNs = old.framePositionNs.takeIf { _ -> it == PlaybackPhase.PAUSED },
                        scrub = old.scrub.takeUnless { _ -> it in setOf(PlaybackPhase.ENDED, PlaybackPhase.FAILED) },
                        loop = old.loop.takeUnless { _ -> it == PlaybackPhase.ENDED })
                } ?: old
            2 -> old.copy(positionMs = first.coerceAtLeast(0), durationMs = second.takeIf { it >= 0 })
            3 -> old.copy(bufferedPercent = first.toInt().coerceIn(0, 100))
            4 -> old.copy(seekable = first != 0L)
            5 -> old.copy(speed = first / 1000.0, failure = null)
            6 -> old.copy(decoders = detail.lineSequence().mapNotNull { line ->
                val values = line.split('\t')
                if (values.size == 3) DecoderInfo(values[0], values[1] == "1", values[2] == "1") else null
            }.take(16).toList())
            7 -> old.copy(processedVideoFrames = first, droppedVideoFrames = second)
            11 -> VideoEffect.entries.getOrNull(first.toInt())?.let {
                old.copy(videoEffect = it, failure = null)
            } ?: old
            12 -> NativeMediaInfo.decode(detail)?.let { old.copy(mediaInfo = it) } ?: old
            13 -> if (first in 0L..10000L && second in 0L..1L)
                old.copy(volume = first / 10000.0, muted = second == 1L) else old
            14 -> when {
                first == -1L && second == -1L -> old.copy(loop = null, failure = null)
                first >= 0 && second <= Long.MAX_VALUE / 1_000_000 && second > first &&
                    second - first >= PlaybackLoop.MIN_DURATION_MS && detail in setOf("", "interval", "video") ->
                    old.copy(loop = PlaybackLoop(first, second, wholeVideo = detail == "video"), failure = null)
                else -> old
            }
            15 -> FrameStepStatus.entries.getOrNull(first.toInt())?.let {
                if (it != FrameStepStatus.IDLE && (old.phase != PlaybackPhase.PAUSED ||
                    old.frameStep != FrameStepStatus.STEPPING)) old else
                    old.copy(frameStep = it, framePositionNs = second.takeIf { ns -> ns >= 0 }, failure = null,
                        positionMs = if (second >= 0) second / 1_000_000 else old.positionMs)
            } ?: old
            16 -> {
                val current = old.scrub
                if (current == null || current.id != second || old.phase !in setOf(
                        PlaybackPhase.PLAYING, PlaybackPhase.PAUSED, PlaybackPhase.BUFFERING)) old
                else if (first == 0L) old.copy(scrub = null)
                else {
                    val status = if (first in 1L..4L) ScrubStatus.entries[first.toInt() - 1] else null
                    val fields = detail.split('\t')
                    val target = fields.getOrNull(0)?.toLongOrNull()
                    val frame = fields.getOrNull(1)?.toLongOrNull()?.takeIf { it >= 0 }
                    val revision = fields.getOrNull(2)?.toLongOrNull() ?: 0
                    if (status == null || target == null || target < 0 || revision != expectedScrubRevision ||
                        (current.status in setOf(ScrubStatus.COMPLETE, ScrubStatus.TIMED_OUT) && status != current.status) ||
                        (status == ScrubStatus.COMPLETE && (current.status != ScrubStatus.SETTLING ||
                            current.requestedPositionMs != target || frame == null)) ||
                        (status == ScrubStatus.TIMED_OUT && current.requestedPositionMs != target)) old
                    else old.copy(scrub = current.copy(
                        status = if (current.status == ScrubStatus.SETTLING && status == ScrubStatus.DRAGGING)
                            ScrubStatus.SETTLING else status,
                        framePositionNs = frame ?: current.framePositionNs),
                        failure = if (status == ScrubStatus.TIMED_OUT) PlaybackFailure(
                            PlaybackErrorCode.SCRUB_TIMEOUT, "video scrub timed out after 5 seconds") else null)
                }
            }
            17 -> NativeAudioTracks.decode(generation, detail)?.let { tracks ->
                if ((tracks.isNotEmpty() && old.phase !in setOf(PlaybackPhase.PLAYING, PlaybackPhase.PAUSED, PlaybackPhase.BUFFERING)) ||
                    (first != -1L && tracks.none { it.index.toLong() == first })) old else
                    old.copy(audioTracks = tracks, selectedAudioTrackIndex = first.toInt().takeIf { it >= 0 },
                        pendingAudioTrack = old.pendingAudioTrack.takeIf { tracks.isNotEmpty() })
            } ?: old
            18 -> {
                val pending = old.pendingAudioTrack
                if (pending == null || pending.id != first) old
                else if (second == pending.index.toLong() && old.audioTracks.any { it.index == pending.index })
                    old.copy(selectedAudioTrackIndex = pending.index, pendingAudioTrack = null, failure = null)
                else old.copy(pendingAudioTrack = null, failure = PlaybackFailure(
                    PlaybackErrorCode.AUDIO_TRACK_UNAVAILABLE, detail.ifEmpty { "native audio selection failed" }))
            }
            19 -> NativeSubtitles.tracks(generation, detail)?.let { tracks ->
                if (tracks.isNotEmpty() && old.phase !in setOf(PlaybackPhase.PLAYING, PlaybackPhase.PAUSED, PlaybackPhase.BUFFERING)) old
                else old.copy(subtitleTracks = tracks,
                    selectedSubtitleTrackIndex = old.selectedSubtitleTrackIndex.takeIf { index -> tracks.any { it.index == index } },
                    pendingSubtitleTrack = old.pendingSubtitleTrack.takeIf { tracks.isNotEmpty() },
                    subtitleCue = old.subtitleCue.takeIf { tracks.isNotEmpty() })
            } ?: old
            20 -> {
                val pending = old.pendingSubtitleTrack
                if (pending == null || pending.id != first) old
                else if (second == (pending.index?.toLong() ?: -1L) &&
                    (pending.index == null || old.subtitleTracks.any { it.index == pending.index }))
                    old.copy(selectedSubtitleTrackIndex = pending.index, pendingSubtitleTrack = null, subtitleCue = null, failure = null)
                else old.copy(selectedSubtitleTrackIndex = null, pendingSubtitleTrack = null, subtitleCue = null,
                    failure = PlaybackFailure(PlaybackErrorCode.SUBTITLE_UNAVAILABLE, detail.ifEmpty { "subtitle selection failed" }))
            }
            21 -> if (old.selectedSubtitleTrackIndex != null && old.pendingSubtitleTrack == null)
                old.copy(subtitleCue = NativeSubtitles.cue(first, second, detail)) else old.copy(subtitleCue = null)
            8, 9 -> {
                val code = PlaybackErrorCode.entries.getOrNull(first.toInt()) ?: PlaybackErrorCode.PIPELINE_FAILED
                old.copy(phase = if (event == 8) PlaybackPhase.FAILED else old.phase,
                    seekable = old.seekable && event != 8, loop = if (event == 8) null else old.loop,
                    frameStep = if (event == 8) FrameStepStatus.IDLE else old.frameStep,
                    framePositionNs = if (event == 8) null else old.framePositionNs,
                    scrub = if (event == 8) null else old.scrub,
                    audioTracks = if (event == 8) emptyList() else old.audioTracks,
                    selectedAudioTrackIndex = if (event == 8) null else old.selectedAudioTrackIndex,
                    pendingAudioTrack = if (event == 8) null else old.pendingAudioTrack,
                    subtitleTracks = if (event == 8) emptyList() else old.subtitleTracks,
                    selectedSubtitleTrackIndex = if (event == 8) null else old.selectedSubtitleTrackIndex,
                    pendingSubtitleTrack = if (event == 8) null else old.pendingSubtitleTrack,
                    subtitleCue = if (event == 8) null else old.subtitleCue,
                    failure = PlaybackFailure(code, detail))
            }
            else -> old
        }
    }
}
