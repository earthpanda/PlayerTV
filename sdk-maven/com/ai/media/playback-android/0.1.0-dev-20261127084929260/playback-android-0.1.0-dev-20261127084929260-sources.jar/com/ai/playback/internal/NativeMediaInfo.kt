package com.ai.playback.internal

import com.ai.playback.MediaInfo

/** Bounded scalar protocol, not a general tags/JSON channel. Invalid envelopes do not clear state. */
internal object NativeMediaInfo {
    fun decode(detail: String): MediaInfo? {
        if (detail.length > 512) return null
        val values = detail.split('\t')
        if (values.size != 14) return null
        val numbers = values.take(12).map { it.toIntOrNull() ?: return null }
        fun positive(index: Int) = numbers[index].takeIf { it > 0 }
        fun codec(index: Int) = values[index].takeIf { it.isNotBlank() && it.length <= 96 }
        return MediaInfo(positive(0), positive(1), positive(2), positive(3),
            positive(4) ?: 1, positive(5) ?: 1, numbers[6].takeIf { it in setOf(0, 90, 180, 270) } ?: 0,
            positive(7), positive(8), numbers[9].coerceAtLeast(0), numbers[10].coerceAtLeast(0),
            numbers[11].coerceAtLeast(0), codec(12), codec(13))
    }
}
