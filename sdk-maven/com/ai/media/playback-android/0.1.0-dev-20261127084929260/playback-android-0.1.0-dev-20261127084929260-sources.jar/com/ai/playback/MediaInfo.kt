package com.ai.playback

/** Current selected streams before output conversion. Unknown format fields remain null.
 * Pixel aspect and rotation are needed to display anamorphic/phone recordings without distortion.
 * Stream counts describe discovery, not a promise that every track is playable/selectable.
 */
data class MediaInfo(
    val videoWidth: Int? = null,
    val videoHeight: Int? = null,
    val frameRateNumerator: Int? = null,
    val frameRateDenominator: Int? = null,
    val pixelAspectNumerator: Int = 1,
    val pixelAspectDenominator: Int = 1,
    val rotationDegrees: Int = 0,
    val audioSampleRateHz: Int? = null,
    val audioChannels: Int? = null,
    val videoStreamCount: Int = 0,
    val audioStreamCount: Int = 0,
    val subtitleStreamCount: Int = 0,
    val videoCodec: String? = null,
    val audioCodec: String? = null,
) {
    val frameRate: Double? get() = frameRateNumerator?.let { n ->
        frameRateDenominator?.takeIf { it > 0 }?.let { n.toDouble() / it }
    }

    val displayAspectRatio: Double? get() {
        val width = videoWidth?.takeIf { it > 0 } ?: return null
        val height = videoHeight?.takeIf { it > 0 } ?: return null
        if (pixelAspectNumerator <= 0 || pixelAspectDenominator <= 0) return null
        val aspect = width.toDouble() * pixelAspectNumerator / pixelAspectDenominator / height
        return if (rotationDegrees == 90 || rotationDegrees == 270) 1.0 / aspect else aspect
    }
}
