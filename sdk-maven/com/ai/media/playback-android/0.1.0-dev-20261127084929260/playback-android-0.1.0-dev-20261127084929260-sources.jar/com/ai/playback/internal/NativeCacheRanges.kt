package com.ai.playback.internal

import com.ai.playback.SessionCacheRange
import com.ai.playback.SessionCacheRanges

internal object NativeCacheRanges {
    fun snapshot(generation: Long, detail: String): SessionCacheRanges? = parse(detail)?.let {
        SessionCacheRanges(generation, java.util.Collections.unmodifiableList(it.toList()))
    }

    fun parse(detail: String): List<SessionCacheRange>? {
        if (detail.isEmpty()) return emptyList()
        if (!detail.endsWith(';')) return null
        val entries = detail.dropLast(1).split(';')
        if (entries.size > 256) return null
        val ranges = ArrayList<SessionCacheRange>(entries.size)
        for (entry in entries) {
            val parts = entry.split(':')
            if (parts.size != 2) return null
            val start = parts[0].toLongOrNull() ?: return null
            val end = parts[1].toLongOrNull() ?: return null
            if (start < 0 || end <= start || (ranges.isNotEmpty() && start <= ranges.last().endPositionMs)) return null
            ranges.add(SessionCacheRange(start, end))
        }
        return ranges
    }
}
