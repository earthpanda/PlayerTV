package com.ai.playback.internal

import com.ai.playback.PlaybackBufferedRange

/** Reject late source/seek facts and malformed native ranges without manufacturing coverage. */
internal object NativeBufferedRanges {
    fun reduce(old: PlaybackBufferedRange?, currentGeneration: Long, eventGeneration: Long,
        epoch: Long, eventEpoch: String, start: Long, end: Long): PlaybackBufferedRange? {
        if (eventGeneration != currentGeneration || eventEpoch.toLongOrNull() != epoch) return old
        if (start == -1L && end == -1L) return null
        if (start < 0 || end <= start) return null
        return PlaybackBufferedRange(eventGeneration, start, end)
    }
}
