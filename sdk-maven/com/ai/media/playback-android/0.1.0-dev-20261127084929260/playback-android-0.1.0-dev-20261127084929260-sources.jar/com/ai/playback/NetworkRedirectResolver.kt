package com.ai.playback

import android.security.NetworkSecurityPolicy
import com.ai.playback.internal.NetworkMediaUri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.IOException
import java.net.HttpURLConnection
import java.net.SocketTimeoutException
import java.net.URI
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.EmptyCoroutineContext
import kotlin.coroutines.resume

/** Result of resolving an HTTP redirect chain. The resolved URI may contain credentials in its
 * query; callers must not log or persist it unnecessarily. A successful response is not proof
 * that the native player can decode the source. */
sealed interface NetworkRedirectResult {
    data class Resolved(val uri: String) : NetworkRedirectResult {
        override fun toString(): String = "Resolved(uri=<redacted>)"
    }
    data class Failed(val reason: NetworkRedirectFailure, val httpStatus: Int? = null) : NetworkRedirectResult
}

enum class NetworkRedirectFailure { INVALID_URI, REDIRECT_REJECTED, TOO_MANY_REDIRECTS, HTTP_ERROR, TIMEOUT, IO_ERROR }

/** Optional preflight for direct media sources. Existing player load methods do not follow
 * redirects and remain unchanged. Run before load, cancel on source replacement or exit,
 * and load the returned URI only if the operation still belongs to the current source.
 * This does not resolve a repository, a playlist's nested requests or authenticated headers. */
object NetworkRedirectResolver {
    suspend fun resolve(uri: String): NetworkRedirectResult =
        RedirectRequest.resolve(uri) { host -> NetworkSecurityPolicy.getInstance().isCleartextTrafficPermitted(host) }
}

internal object RedirectRequest {
    private const val MAX_REDIRECTS = 5
    private const val TIMEOUT_MS = 15_000

    suspend fun resolve(input: String, cleartextAllowed: (String) -> Boolean): NetworkRedirectResult =
        suspendCancellableCoroutine { continuation ->
            val active = AtomicReference<HttpURLConnection?>(null)
            val worker = CoroutineScope(continuation.context + Dispatchers.IO).launch {
                val result = try {
                    follow(input, cleartextAllowed, active) { continuation.isActive }
                } catch (_: SocketTimeoutException) {
                    NetworkRedirectResult.Failed(NetworkRedirectFailure.TIMEOUT)
                } catch (_: IOException) {
                    NetworkRedirectResult.Failed(NetworkRedirectFailure.IO_ERROR)
                } catch (_: IllegalArgumentException) {
                    NetworkRedirectResult.Failed(NetworkRedirectFailure.INVALID_URI)
                } finally {
                    active.getAndSet(null)?.disconnect()
                }
                if (continuation.isActive) continuation.resume(result)
            }
            continuation.invokeOnCancellation {
                worker.cancel()
                // Disconnect away from the caller's thread. This also unblocks a pending read
                // where the platform HTTP implementation supports it.
                Dispatchers.IO.dispatch(EmptyCoroutineContext, Runnable { active.getAndSet(null)?.disconnect() })
            }
        }

    private fun follow(input: String, cleartextAllowed: (String) -> Boolean,
        active: AtomicReference<HttpURLConnection?>, isActive: () -> Boolean): NetworkRedirectResult {
        if (!NetworkMediaUri.allowed(input, false, cleartextAllowed))
            return NetworkRedirectResult.Failed(NetworkRedirectFailure.INVALID_URI)
        var current = URI(input)
        val visited = mutableSetOf<String>()
        var redirects = 0
        while (isActive()) {
            if (!visited.add(current.normalize().toASCIIString()))
                return NetworkRedirectResult.Failed(NetworkRedirectFailure.REDIRECT_REJECTED)
            val connection = current.toURL().openConnection() as HttpURLConnection
            active.set(connection)
            if (!isActive()) break
            connection.instanceFollowRedirects = false
            connection.connectTimeout = TIMEOUT_MS
            connection.readTimeout = TIMEOUT_MS
            connection.requestMethod = "GET"
            connection.setRequestProperty("Range", "bytes=0-0")
            val status = connection.responseCode
            if (!isActive()) break
            if (status == 200 || status == 206) return NetworkRedirectResult.Resolved(current.toASCIIString())
            if (status !in setOf(301, 302, 303, 307, 308))
                return NetworkRedirectResult.Failed(NetworkRedirectFailure.HTTP_ERROR, status)
            if (redirects++ >= MAX_REDIRECTS)
                return NetworkRedirectResult.Failed(NetworkRedirectFailure.TOO_MANY_REDIRECTS)
            val location = connection.getHeaderField("Location")
                ?: return NetworkRedirectResult.Failed(NetworkRedirectFailure.REDIRECT_REJECTED)
            val next = try { current.resolve(location) } catch (_: IllegalArgumentException) {
                return NetworkRedirectResult.Failed(NetworkRedirectFailure.REDIRECT_REJECTED)
            }
            if (!NetworkMediaUri.allowed(next.toASCIIString(), false, cleartextAllowed) ||
                (current.scheme == "https" && next.scheme == "http"))
                return NetworkRedirectResult.Failed(NetworkRedirectFailure.REDIRECT_REJECTED)
            active.compareAndSet(connection, null)
            connection.disconnect()
            current = next
        }
        return NetworkRedirectResult.Failed(NetworkRedirectFailure.IO_ERROR)
    }
}
