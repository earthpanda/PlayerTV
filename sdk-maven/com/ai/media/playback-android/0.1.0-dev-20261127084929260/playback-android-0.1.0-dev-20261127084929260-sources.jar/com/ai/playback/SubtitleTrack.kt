package com.ai.playback

/** Text stream, valid only for the generation returned in the same snapshot. */
data class SubtitleTrack(val generation: Long, val index: Int, val title: String = "",
    val language: String = "", val codec: String = "", val external: Boolean = false)

/** index == null means turning subtitles off. Accepted is admission, not selection confirmation. */
data class SubtitleTrackChange(val id: Long, val index: Int?)

/** Plain text, including line breaks. Times are media ns; the SDK owns timing/clearing. */
data class SubtitleCue(val text: String, val startPositionNs: Long, val endPositionNs: Long)
