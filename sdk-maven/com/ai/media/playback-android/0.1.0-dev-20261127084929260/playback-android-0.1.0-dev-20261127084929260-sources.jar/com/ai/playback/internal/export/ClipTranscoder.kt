package com.ai.playback.internal.export

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaCodecList
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMuxer
import android.os.Build
import android.os.SystemClock
import com.ai.playback.ClipExportError
import com.ai.playback.ClipExportException
import com.ai.playback.ClipExportRequest
import com.ai.playback.VideoEffect
import com.ai.playback.ClipExportResult
import java.io.FileDescriptor
import java.nio.ByteBuffer

internal fun fail(code: ClipExportError): Nothing = throw ClipExportException(code)
internal fun MediaFormat.intOr(key: String, fallback: Int) = if (containsKey(key)) getInteger(key) else fallback
internal fun extractor(fd: FileDescriptor) = MediaExtractor().also {
    try { it.setDataSource(fd) } catch (error: Throwable) { it.release(); throw error }
}

/** Run every cleanup even if a platform release fails; preserve the original failure through use(). */
internal fun closeAll(vararg actions: () -> Unit) {
    var failure: Throwable? = null
    for (action in actions) try { action() } catch (error: Throwable) {
        if (failure == null) failure=error else failure.addSuppressed(error)
    }
    failure?.let { throw it }
}

internal fun releaseCodec(codec: MediaCodec?) {
    if (codec != null) try { codec.stop() } finally { codec.release() }
}

internal fun configuredHardwareCodec(format: MediaFormat, encoder: Boolean, surface: android.view.Surface? = null): MediaCodec {
    val mime = requireNotNull(format.getString(MediaFormat.KEY_MIME))
    val candidates = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.filter { info ->
        info.isEncoder == encoder && (if (Build.VERSION.SDK_INT >= 29) info.isHardwareAccelerated
            else info.name.startsWith("OMX.") && !info.name.startsWith("OMX.google.") &&
                !info.name.contains(".sw.",true)) &&
            info.supportedTypes.any { it.equals(mime,true) } &&
            try { info.getCapabilitiesForType(mime).isFormatSupported(format) } catch (_: IllegalArgumentException) { false }
    }.distinctBy { it.name }
    if(candidates.isEmpty()) fail(ClipExportError.UNSUPPORTED_CODEC)
    val failures=mutableListOf<Throwable>()
    // Advertised capabilities do not establish that a vendor implementation can configure.
    // Try each compatible hardware factory once, releasing rejected candidates before the next.
    // This is finite initial negotiation, never a playback retry or a software fallback.
    for(candidate in candidates) {
        var codec: MediaCodec?=null
        try {
            codec=MediaCodec.createByCodecName(candidate.name)
            codec.configure(format,surface,null,if(encoder) MediaCodec.CONFIGURE_FLAG_ENCODE else 0)
            return codec
        } catch(error: Exception) {
            val reason=IllegalStateException("Codec configuration rejected: "+candidate.name,error)
            try { codec?.release() } catch(cleanup: Exception) { reason.addSuppressed(cleanup) }
            failures.add(reason)
        }
    }
    throw ClipExportException(ClipExportError.CODEC_FAILED,failures.last()).apply {
        failures.dropLast(1).forEach(::addSuppressed)
    }
}

internal class ClipMuxer(output: FileDescriptor, private val hasAudio: Boolean,
    private val durationUs: Long, rotation: Int) : AutoCloseable {
    private val muxer=MediaMuxer(output,MediaMuxer.OutputFormat.MUXER_OUTPUT_MPEG_4)
    private var videoTrack=-1
    private var audioTrack=-1
    var started=false; private set
    var videoFrames=0L; private set
    private var audioFrames=0L
    private var lastVideo=-1L
    private var lastAudio=Long.MIN_VALUE
    init {
        try { muxer.setOrientationHint(rotation) }
        catch (error: Throwable) { muxer.release(); throw error }
    }
    fun format(video: Boolean, format: MediaFormat) {
        if (started || (if(video) videoTrack else audioTrack)>=0) fail(ClipExportError.CODEC_FAILED)
        val track=muxer.addTrack(format)
        if(video) videoTrack=track else audioTrack=track
        if(videoTrack>=0 && (!hasAudio || audioTrack>=0)) { muxer.start(); started=true }
    }
    fun sample(video: Boolean, data: ByteBuffer, info: MediaCodec.BufferInfo) {
        if(info.size<=0 || info.flags and MediaCodec.BUFFER_FLAG_CODEC_CONFIG!=0) return
        // Retain negative AAC priming timestamps. MP4's edit list trims the pre-zero samples;
        // dropping their packets loses decoder history and changes the common movie origin.
        if((video && info.presentationTimeUs<0) || info.presentationTimeUs>=durationUs) return
        val last=if(video) lastVideo else lastAudio
        if(info.presentationTimeUs<=last) fail(ClipExportError.CODEC_FAILED)
        muxer.writeSampleData(if(video) videoTrack else audioTrack,data,info)
        if(video) { lastVideo=info.presentationTimeUs; videoFrames++ }
        else { lastAudio=info.presentationTimeUs; audioFrames++ }
    }
    fun finish() {
        if(!started || videoFrames==0L || (hasAudio && audioFrames==0L)) fail(ClipExportError.NO_FRAMES)
        // Explicit final sample duration: Android's MP4 muxer otherwise guesses from the previous interval.
        val end=MediaCodec.BufferInfo().apply { set(0,0,durationUs,MediaCodec.BUFFER_FLAG_END_OF_STREAM) }
        muxer.writeSampleData(videoTrack,ByteBuffer.allocate(0),end)
        if(hasAudio) muxer.writeSampleData(audioTrack,ByteBuffer.allocate(0),end)
        muxer.stop(); started=false
    }
    override fun close() { try { if(started) { started=false; muxer.stop() } } finally { muxer.release() } }
}

/** At most one codec-owned output buffer is held while the other track supplies its format. */
internal class EncodedOutput(private val codec: MediaCodec, private val muxer: ClipMuxer, private val video: Boolean) {
    private val info=MediaCodec.BufferInfo()
    private var pending=-1
    var done=false; private set
    val blocked: Boolean get() = pending>=0 && !muxer.started
    fun drain(): Boolean {
        if(done) return false
        if(pending<0) {
            val index=codec.dequeueOutputBuffer(info,0)
            if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) { muxer.format(video,codec.outputFormat); return true }
            if(index<0) return false
            pending=index
        }
        if(!muxer.started) return false
        val index=pending
        try {
            muxer.sample(video,requireNotNull(codec.getOutputBuffer(index)),info)
            if(info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM!=0) done=true
        } finally { codec.releaseOutputBuffer(index,false); pending=-1 }
        return true
    }
}

/** Independent extractors avoid shared mutable track/seek state between audio and video. */
internal class ClipDecoder(fd: FileDescriptor, track: Int, startUs: Long, video: Boolean,
    surface: android.view.Surface? = null) : AutoCloseable {
    private val source=extractor(fd)
    lateinit var codec: MediaCodec; private set
    private var inputEnded=false
    init {
        try {
            source.selectTrack(track); source.seekTo(startUs,MediaExtractor.SEEK_TO_PREVIOUS_SYNC)
            val format=source.getTrackFormat(track)
            if(video) format.setInteger(MediaFormat.KEY_ROTATION,0) // Rotation remains an MP4 display hint.
            codec=if(video) configuredHardwareCodec(format,false,surface)
                else MediaCodec.createDecoderByType(requireNotNull(format.getString(MediaFormat.KEY_MIME)))
            if(!video) codec.configure(format,surface,null,0)
            codec.start()
        } catch(error: Throwable) {
            try { close() } catch(cleanup: Throwable) { error.addSuppressed(cleanup) }; throw error
        }
    }
    fun feed(): Boolean {
        if(inputEnded) return false
        val index=codec.dequeueInputBuffer(0)
        if(index<0) return false
        val input=requireNotNull(codec.getInputBuffer(index)); input.clear()
        if(source.sampleTime<0) {
            codec.queueInputBuffer(index,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputEnded=true
        } else {
            if(source.sampleFlags and MediaExtractor.SAMPLE_FLAG_ENCRYPTED!=0) fail(ClipExportError.UNSUPPORTED_SOURCE)
            if(source.sampleSize>input.capacity()) fail(ClipExportError.UNSUPPORTED_SOURCE)
            val size=source.readSampleData(input,0)
            if(size<0) { codec.queueInputBuffer(index,0,0,0,MediaCodec.BUFFER_FLAG_END_OF_STREAM); inputEnded=true }
            else {
                codec.queueInputBuffer(index,0,size,source.sampleTime,0)
                source.advance()
            }
        }
        return true
    }
    override fun close() = closeAll({ if(::codec.isInitialized) releaseCodec(codec) },{ source.release() })
}

internal class ClipTranscoder(input: FileDescriptor, output: FileDescriptor,
    private val request: ClipExportRequest, videoEffect: VideoEffect,
    private val checkCancelled: () -> Unit) : AutoCloseable {
    private var muxer: ClipMuxer?=null
    private var video: ClipVideoPipeline?=null
    private var audio: ClipAudioPipeline?=null
    init {
        try {
            val source=extractor(input)
            try {
                val videoTracks=(0 until source.trackCount).filter { source.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("video/")==true }
                val audioTracks=(0 until source.trackCount).filter { source.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/")==true }
                if(videoTracks.isEmpty() || (request.expectedAudioTrackCount!=null && request.expectedAudioTrackCount!=audioTracks.size))
                    fail(ClipExportError.UNSUPPORTED_SOURCE)
                val audioTrack=request.audioTrackIndex?.let { audioTracks.getOrNull(it) ?: fail(ClipExportError.UNSUPPORTED_SOURCE) }
                val format=source.getTrackFormat(videoTracks[0])
                if(!format.containsKey(MediaFormat.KEY_DURATION) || request.endPositionMs*1000>format.getLong(MediaFormat.KEY_DURATION)+1000)
                    fail(ClipExportError.INVALID_RANGE)
                val rotation=format.intOr(MediaFormat.KEY_ROTATION,0)
                if(rotation !in setOf(0,90,180,270)) fail(ClipExportError.UNSUPPORTED_SOURCE)
                val sink=ClipMuxer(output,audioTrack!=null,(request.endPositionMs-request.startPositionMs)*1000,rotation)
                muxer=sink
                video=ClipVideoPipeline(input,videoTracks[0],format,request,videoEffect,sink,checkCancelled)
                if(audioTrack!=null) audio=ClipAudioPipeline(input,audioTrack,source.getTrackFormat(audioTrack),request,sink)
            } finally { source.release() }
        } catch(error: Throwable) {
            try { close() } catch(cleanup: Throwable) { error.addSuppressed(cleanup) }; throw error
        }
    }
    suspend fun run(onProgress: suspend (Int)->Unit): ClipExportResult {
        val picture=requireNotNull(video); val sound=audio
        var lastActivity=SystemClock.elapsedRealtime()
        var lastReport=lastActivity
        onProgress(0)
        while(!picture.done || sound?.done==false) {
            checkCancelled()
            val audioActive=sound?.tick()==true
            val videoActive=picture.tick()
            val now=SystemClock.elapsedRealtime()
            if(audioActive || videoActive) lastActivity=now
            else {
                if(now-lastActivity>10000) fail(ClipExportError.TIMED_OUT)
                Thread.sleep(2)
            }
            if(now-lastReport>=200) {
                val position=minOf(picture.positionUs,sound?.positionUs ?: Long.MAX_VALUE)
                val fraction=((position-request.startPositionMs*1000)*100/(request.endPositionMs-request.startPositionMs)/1000).toInt()
                onProgress(fraction.coerceIn(0,99)); lastReport=now
            }
        }
        checkCancelled()
        requireNotNull(muxer).finish()
        onProgress(100)
        return ClipExportResult(picture.width,picture.height,requireNotNull(muxer).videoFrames,
            picture.firstUs,picture.lastUs,picture.decoderName,picture.encoderName)
    }
    override fun close() = closeAll({ audio?.close(); audio=null },{ video?.close(); video=null },{ muxer?.close(); muxer=null })
}
