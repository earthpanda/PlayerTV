package com.ai.playback.internal

import java.net.URI
import java.net.URISyntaxException

/** Admission only: never resolves, downloads, logs or rewrites a signed media URL. */
internal object NetworkMediaUri {
    fun allowed(value: String, httpsOnly: Boolean, cleartextAllowed: (String) -> Boolean): Boolean {
        val uri = try { URI(value) } catch (_: URISyntaxException) { return false }
        val host = uri.host?.takeIf { it.isNotBlank() } ?: return false
        if (uri.isOpaque || uri.rawUserInfo != null || uri.rawFragment != null ||
            (uri.port != -1 && uri.port !in 1..65535)) return false
        return when (uri.scheme) {
            "https" -> true
            "http" -> !httpsOnly && cleartextAllowed(host)
            else -> false
        }
    }
}
