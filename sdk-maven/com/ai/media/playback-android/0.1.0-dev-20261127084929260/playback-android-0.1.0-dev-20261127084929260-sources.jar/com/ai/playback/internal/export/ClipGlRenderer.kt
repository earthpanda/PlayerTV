package com.ai.playback.internal.export

import android.graphics.SurfaceTexture
import android.opengl.EGL14
import android.opengl.EGLConfig
import android.opengl.EGLExt
import android.opengl.GLES11Ext
import android.opengl.GLES20
import android.os.Handler
import android.os.HandlerThread
import android.os.SystemClock
import android.view.Surface
import com.ai.playback.ClipExportError
import com.ai.playback.ClipExportException
import com.ai.playback.VideoEffect
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Single export-worker EGL owner. Exactly one released decoder frame is awaited at a time. */
internal class ClipGlRenderer(private val encoderSurface: Surface, private val width: Int,
    private val height: Int, videoEffect: VideoEffect, private val checkCancelled: () -> Unit) : AutoCloseable {
    private val display = EGL14.eglGetDisplay(EGL14.EGL_DEFAULT_DISPLAY)
    private var context = EGL14.EGL_NO_CONTEXT
    private var window = EGL14.EGL_NO_SURFACE
    private var texture = 0
    private var program = 0
    private var closed = false
    private var frames: HandlerThread? = null
    private var image: SurfaceTexture? = null
    private var ownedSurface: Surface? = null
    val decoderSurface: Surface get() = requireNotNull(ownedSurface)
    private val signal = Object()
    private var available = false
    private val matrix = FloatArray(16)
    private val vertices = ByteBuffer.allocateDirect(16 * 4).order(ByteOrder.nativeOrder()).asFloatBuffer().apply {
        put(floatArrayOf(-1f,-1f,0f,0f, 1f,-1f,1f,0f, -1f,1f,0f,1f, 1f,1f,1f,1f)); position(0)
    }

    init {
        try {
            checkGl(EGL14.eglInitialize(display, IntArray(2), 0, IntArray(2), 0))
            val configs = arrayOfNulls<EGLConfig>(1)
            val count = IntArray(1)
            checkGl(EGL14.eglChooseConfig(display, intArrayOf(EGL14.EGL_RED_SIZE,8,EGL14.EGL_GREEN_SIZE,8,
                EGL14.EGL_BLUE_SIZE,8,EGL14.EGL_ALPHA_SIZE,8,EGL14.EGL_RENDERABLE_TYPE,EGL14.EGL_OPENGL_ES2_BIT,
                EGL14.EGL_SURFACE_TYPE,EGL14.EGL_WINDOW_BIT,0x3142,1,EGL14.EGL_NONE),0,configs,0,1,count,0) && count[0]>0)
            context = EGL14.eglCreateContext(display, configs[0], EGL14.EGL_NO_CONTEXT,
                intArrayOf(EGL14.EGL_CONTEXT_CLIENT_VERSION,2,EGL14.EGL_NONE),0)
            checkGl(context != EGL14.EGL_NO_CONTEXT)
            window = EGL14.eglCreateWindowSurface(display, configs[0], encoderSurface, intArrayOf(EGL14.EGL_NONE),0)
            checkGl(window != EGL14.EGL_NO_SURFACE && EGL14.eglMakeCurrent(display,window,window,context))
            val names = IntArray(1)
            GLES20.glGenTextures(1,names,0); texture=names[0]
            GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MIN_FILTER,GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_MAG_FILTER,GLES20.GL_LINEAR)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_S,GLES20.GL_CLAMP_TO_EDGE)
            GLES20.glTexParameteri(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,GLES20.GL_TEXTURE_WRAP_T,GLES20.GL_CLAMP_TO_EDGE)
            val vertex = shader(GLES20.GL_VERTEX_SHADER,
                "attribute vec4 p; attribute vec4 t; uniform mat4 m; varying vec2 uv; void main(){gl_Position=p; uv=(m*t).xy;}")
            // Compile once for this task. Both paths sample the hardware decoder's OES texture;
            // grayscale shares playback's SDR weights, preserves alpha, and never reads pixels to CPU.
            val body = when(videoEffect) {
                VideoEffect.NONE -> "gl_FragColor=texture2D(s,uv);"
                VideoEffect.GRAYSCALE -> "vec4 c=texture2D(s,uv); float y=dot(c.rgb,vec3(0.299,0.587,0.114)); gl_FragColor=vec4(vec3(y),c.a);"
            }
            val fragment = try { shader(GLES20.GL_FRAGMENT_SHADER,
                "#extension GL_OES_EGL_image_external : require\nprecision mediump float; uniform samplerExternalOES s; varying vec2 uv; void main(){"+body+"}") }
                catch (error: Throwable) { GLES20.glDeleteShader(vertex); throw error }
            program=GLES20.glCreateProgram()
            GLES20.glAttachShader(program,vertex); GLES20.glAttachShader(program,fragment); GLES20.glLinkProgram(program)
            GLES20.glDeleteShader(vertex); GLES20.glDeleteShader(fragment)
            val status=IntArray(1); GLES20.glGetProgramiv(program,GLES20.GL_LINK_STATUS,status,0); checkGl(status[0]!=0)
            frames=HandlerThread("ClipFrames").also { it.start() }
            image=SurfaceTexture(texture).also { surface ->
                surface.setDefaultBufferSize(width,height)
                surface.setOnFrameAvailableListener({ synchronized(signal) { available=true; signal.notifyAll() } },
                    Handler(requireNotNull(frames).looper))
            }
            ownedSurface=Surface(requireNotNull(image))
            checkGl(GLES20.glGetError()==GLES20.GL_NO_ERROR)
        } catch (error: Throwable) {
            try { close() } catch (cleanup: Throwable) { error.addSuppressed(cleanup) }
            throw error
        }
    }

    fun draw(positionUs: Long) {
        val deadline=SystemClock.elapsedRealtime()+3000
        synchronized(signal) {
            while (!available) {
                checkCancelled()
                if (SystemClock.elapsedRealtime()>=deadline) throw ClipExportException(ClipExportError.TIMED_OUT)
                signal.wait(50)
            }
            available=false
        }
        checkCancelled()
        val frame=requireNotNull(image)
        frame.updateTexImage(); frame.getTransformMatrix(matrix)
        GLES20.glViewport(0,0,width,height); GLES20.glUseProgram(program)
        GLES20.glActiveTexture(GLES20.GL_TEXTURE0); GLES20.glBindTexture(GLES11Ext.GL_TEXTURE_EXTERNAL_OES,texture)
        GLES20.glUniform1i(GLES20.glGetUniformLocation(program,"s"),0)
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(program,"m"),1,false,matrix,0)
        val p=GLES20.glGetAttribLocation(program,"p"); val t=GLES20.glGetAttribLocation(program,"t")
        vertices.position(0); GLES20.glVertexAttribPointer(p,2,GLES20.GL_FLOAT,false,16,vertices)
        vertices.position(2); GLES20.glVertexAttribPointer(t,2,GLES20.GL_FLOAT,false,16,vertices)
        GLES20.glEnableVertexAttribArray(p); GLES20.glEnableVertexAttribArray(t)
        GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP,0,4)
        checkGl(GLES20.glGetError()==GLES20.GL_NO_ERROR)
        checkGl(EGLExt.eglPresentationTimeANDROID(display,window,positionUs*1000))
        checkGl(EGL14.eglSwapBuffers(display,window))
    }

    override fun close() {
        if(closed) return
        closed=true
        closeAll(
            { image?.setOnFrameAvailableListener(null) },
            { ownedSurface?.release(); ownedSurface=null },
            { image?.release(); image=null },
            {
                if (context!=EGL14.EGL_NO_CONTEXT && window!=EGL14.EGL_NO_SURFACE &&
                    EGL14.eglMakeCurrent(display,window,window,context)) {
                    if (program!=0) GLES20.glDeleteProgram(program)
                    if (texture!=0) GLES20.glDeleteTextures(1,intArrayOf(texture),0)
                }
                program=0; texture=0
            },
            { EGL14.eglMakeCurrent(display,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_SURFACE,EGL14.EGL_NO_CONTEXT) },
            { if (window!=EGL14.EGL_NO_SURFACE) EGL14.eglDestroySurface(display,window); window=EGL14.EGL_NO_SURFACE },
            { if (context!=EGL14.EGL_NO_CONTEXT) EGL14.eglDestroyContext(display,context); context=EGL14.EGL_NO_CONTEXT },
            { EGL14.eglReleaseThread() },
            { EGL14.eglTerminate(display) },
            { encoderSurface.release() },
            { frames?.quitSafely() },
            { frames?.join(500); frames=null }
        )
    }

    private fun shader(type: Int, source: String): Int {
        val shader=GLES20.glCreateShader(type)
        GLES20.glShaderSource(shader,source); GLES20.glCompileShader(shader)
        val status=IntArray(1); GLES20.glGetShaderiv(shader,GLES20.GL_COMPILE_STATUS,status,0)
        if (status[0]==0) { GLES20.glDeleteShader(shader); throw ClipExportException(ClipExportError.UNSUPPORTED_CODEC) }
        return shader
    }
    private fun checkGl(ok: Boolean) { if (!ok) throw ClipExportException(ClipExportError.UNSUPPORTED_CODEC) }
}
