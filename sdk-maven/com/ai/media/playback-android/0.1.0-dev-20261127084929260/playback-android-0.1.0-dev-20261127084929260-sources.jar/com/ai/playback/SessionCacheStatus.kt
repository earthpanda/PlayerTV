package com.ai.playback

/** State for the current load only. Attached means the temporary store is open;
 * it does not imply that any particular media time is cached or playable. */
data class SessionCacheStatus(val generation: Long, val phase: Phase, val reason: FallbackReason? = null) {
    enum class Phase { PREPARING, ATTACHED, FALLBACK }

    /** Why this session returned to ordinary network reading. Unknown preserves
     * forward compatibility if a newer native library adds another cause. */
    enum class FallbackReason {
        UNCACHEABLE_ORIGIN, CHANGED_ORIGIN, INVALID_RESPONSE, INVALID_BODY, MISSING_IDENTITY,
        OFFSET_MISMATCH, CAPACITY, STORAGE_UNAVAILABLE, STORAGE_IO, REQUEST_EXHAUSTED, INTERNAL, UNKNOWN;

        internal companion object {
            fun fromNative(code: Long): FallbackReason = when (code) {
                1L -> UNCACHEABLE_ORIGIN
                2L -> CHANGED_ORIGIN
                3L -> INVALID_RESPONSE
                4L -> INVALID_BODY
                5L -> MISSING_IDENTITY
                6L -> OFFSET_MISMATCH
                7L -> CAPACITY
                8L -> STORAGE_UNAVAILABLE
                9L -> STORAGE_IO
                10L -> REQUEST_EXHAUSTED
                11L -> INTERNAL
                else -> UNKNOWN
            }
        }
    }
}
