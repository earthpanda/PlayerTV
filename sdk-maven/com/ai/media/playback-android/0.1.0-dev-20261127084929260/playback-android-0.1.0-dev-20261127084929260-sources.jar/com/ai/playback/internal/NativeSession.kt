package com.ai.playback.internal

import android.os.Handler
import android.os.Looper
import android.os.ParcelFileDescriptor
import android.os.SystemClock
import android.view.Surface
import android.media.MediaCodecList
import android.media.MediaCodecInfo
import android.os.Build
import com.ai.playback.PlaybackRecording
import com.ai.playback.RecordingOptions
import com.ai.playback.RecordingException
import com.ai.playback.CommandResult
import com.ai.playback.PlaybackErrorCode
import com.ai.playback.PlaybackFailure
import com.ai.playback.PlaybackBufferedRange
import com.ai.playback.PlaybackOptions
import com.ai.playback.PlaybackPhase
import com.ai.playback.PlaybackSnapshot
import com.ai.playback.FrameStepStatus
import com.ai.playback.ScrubStatus
import com.ai.playback.VideoScrub
import com.ai.playback.AudioTrack
import com.ai.playback.AudioTrackChange
import com.ai.playback.SubtitleTrack
import com.ai.playback.SubtitleTrackChange
import com.ai.playback.SubtitlePositionNotice
import com.ai.playback.SessionCacheStatus
import com.ai.playback.SessionCacheRanges
import com.ai.playback.SrtSubtitle
import com.ai.playback.VideoFrame
import com.ai.playback.FrameCaptureException
import com.ai.playback.FrameCaptureError
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CancellableContinuation
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeout
import kotlinx.coroutines.TimeoutCancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

/** Main-thread API. Native owns one bounded command mailbox and one GLib control loop per session. */
internal class NativeSession {
    private val handler = Handler(Looper.getMainLooper())
    private val callbackToken = Any()
    private val eventLock = Any()
    private data class NativeEvent(val generation: Long, val kind: Int, val first: Long, val second: Long, val detail: String)
    // Retain only the newest event of each kind for the newest source. A busy UI must not
    // accumulate an unbounded Handler queue while the native control loop keeps ticking (25 event kinds).
    private val pendingEvents = linkedMapOf<Int, NativeEvent>()
    private var pendingGeneration = -1L
    private var deliveryScheduled = false
    private val mutableState = MutableStateFlow(PlaybackSnapshot())
    val state = mutableState.asStateFlow()
    private val mutableBufferedRange = MutableStateFlow<PlaybackBufferedRange?>(null)
    val bufferedRange = mutableBufferedRange.asStateFlow()
    private val mutableSubtitlePositionNotice = MutableStateFlow<SubtitlePositionNotice?>(null)
    val subtitlePositionNotice = mutableSubtitlePositionNotice.asStateFlow()
    private val mutableSessionCacheStatus = MutableStateFlow<SessionCacheStatus?>(null)
    val sessionCacheStatus = mutableSessionCacheStatus.asStateFlow()
    private val mutableSessionCacheRanges = MutableStateFlow<SessionCacheRanges?>(null)
    val sessionCacheRanges = mutableSessionCacheRanges.asStateFlow()
    private var sessionCacheGeneration: Long? = null
    private var bufferEpoch = 0L
    private var bufferTrackingDisabled = false
    private var surfaceAvailable = false
    private var handle = nativeCreate()
    private val released = CompletableDeferred<Unit>()
    private var nextScrubId = 0L
    // Main-thread ownership follows the current gesture; it is not part of the public snapshot ABI.
    private var scrubRevision = 0L
    private var nextAudioChangeId = 0L
    private var nextSubtitleChangeId = 0L
    private var activeSubtitleChangeId = 0L
    private var nextCaptureId = 0L
    private data class Capture(val id: Long, val generation: Long, val result: CancellableContinuation<VideoFrame>)
    private var capture: Capture? = null // Main-thread only; pixel delivery is one cancellable Handler task.
    private val captureToken = Any()
    private var recording: PlaybackRecording? = null

    fun startRecording(output: ParcelFileDescriptor, options: RecordingOptions): PlaybackRecording {
        checkMain()
        val current = state.value
        if (handle == 0L || recording?.state?.value?.finished == false ||
            current.phase !in setOf(PlaybackPhase.PLAYING, PlaybackPhase.PAUSED, PlaybackPhase.BUFFERING) ||
            (current.scrub?.active == true || current.scrub?.status == ScrubStatus.TIMED_OUT) || current.frameStep == FrameStepStatus.STEPPING)
            throw RecordingException("recording requires a prepared video and no active recording")
        val encoder = MediaCodecList(MediaCodecList.REGULAR_CODECS).codecInfos.firstOrNull { codec ->
            codec.isEncoder && (if (Build.VERSION.SDK_INT >= 29) codec.isHardwareAccelerated
                else codec.name.startsWith("OMX.") && !codec.name.startsWith("OMX.google.") && !codec.name.contains(".sw.",true)) &&
                codec.supportedTypes.any { it.equals("video/avc",true) } &&
                try {
                    val caps = codec.getCapabilitiesForType("video/avc")
                    MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface in caps.colorFormats &&
                        caps.videoCapabilities.isSizeSupported(options.width, options.height)
                } catch (_: IllegalArgumentException) { false }
        } ?: throw RecordingException("no hardware H264 encoder for recording canvas")
        val lease = nativeStartRecording(handle, current.generation, output.fd, options.width, options.height, encoder.name)
        if (lease == 0L) throw RecordingException("recording rejected: output must be an empty regular file")
        return PlaybackRecording(lease, options) { id, cancel ->
            handle != 0L && nativeFinishRecording(handle, id, cancel)
        }.also { recording = it }
    }

    suspend fun captureFrame(): VideoFrame {
        checkMain()
        if (capture != null) throw FrameCaptureException(FrameCaptureError.BUSY)
        val current = mutableState.value
        if (handle == 0L || current.phase !in setOf(PlaybackPhase.PLAYING, PlaybackPhase.PAUSED, PlaybackPhase.BUFFERING) ||
            current.frameStep == FrameStepStatus.STEPPING || current.scrub?.active == true || current.scrub?.status == ScrubStatus.TIMED_OUT ||
            nextCaptureId == Long.MAX_VALUE) throw FrameCaptureException(FrameCaptureError.NO_FRAME)
        val id = ++nextCaptureId
        try {
            return withTimeout(5000) {
                suspendCancellableCoroutine { continuation ->
                    capture = Capture(id, current.generation, continuation)
                    continuation.invokeOnCancellation {
                        handler.postAtTime({ cancelCapture(id) }, captureToken, SystemClock.uptimeMillis())
                    }
                    if (!nativeCapture(handle, current.generation, id)) {
                        capture = null
                        continuation.resumeWithException(FrameCaptureException(FrameCaptureError.BUSY))
                    }
                }
            }
        } catch (timeout: TimeoutCancellationException) {
            currentCoroutineContext().ensureActive() // Preserve cancellation by an outer owner/timeout.
            throw FrameCaptureException(FrameCaptureError.TIMED_OUT)
        } finally {
            if (capture?.id == id) cancelCapture(id)
        }
    }

    private fun cancelCapture(id: Long? = capture?.id) {
        val pending = capture?.takeIf { it.id == id } ?: return
        capture = null
        handler.removeCallbacksAndMessages(captureToken)
        if (handle != 0L) nativeCancelCapture(handle, pending.id)
        pending.result.cancel(CancellationException("video frame source/capture invalidated"))
    }

    @Suppress("unused")
    private fun onNativeCapture(generation: Long, id: Long, positionNs: Long, width: Int, height: Int,
        detail: String, rgba: ByteArray?) {
        handler.postAtTime({
            val pending = capture?.takeIf { it.id == id && it.generation == generation } ?: return@postAtTime
            capture = null
            if (!pending.result.isActive) return@postAtTime
            if (handle == 0L || generation != mutableState.value.generation) {
                pending.result.cancel(CancellationException("frame source changed"))
            } else if (rgba == null) {
                val code = FrameCaptureError.entries.firstOrNull { it.name == detail } ?: FrameCaptureError.READBACK_FAILED
                pending.result.resumeWithException(FrameCaptureException(code))
            } else {
                try { pending.result.resume(VideoFrame(generation, positionNs, width, height, detail, rgba)) }
                catch (_: IllegalArgumentException) {
                    pending.result.resumeWithException(FrameCaptureException(FrameCaptureError.READBACK_FAILED))
                }
            }
        }, captureToken, SystemClock.uptimeMillis())
    }

    fun load(descriptor: ParcelFileDescriptor?, httpsUri: String?, testSource: Boolean, options: PlaybackOptions): CommandResult =
        loadInternal(descriptor, httpsUri, testSource, options, null)

    // Shared by AndroidPlayer's opt-in entry; native owns this source's cache lifetime.
    fun loadWithSessionCache(uri: String, options: PlaybackOptions, directory: String, capacityBytes: Long): CommandResult =
        loadInternal(null, uri, false, options, directory to capacityBytes)

    private fun loadInternal(descriptor: ParcelFileDescriptor?, httpsUri: String?, testSource: Boolean,
        options: PlaybackOptions, cache: Pair<String, Long>?): CommandResult {
        checkMain()
        if (handle == 0L) return rejected("session closed")
        val next = mutableState.value.generation + 1
        val accepted = if (cache == null) nativeLoad(handle, next, descriptor?.fd ?: -1, httpsUri,
            testSource, options.decoderMode.ordinal, options.videoEffect.ordinal, options.playWhenReady, options.startPositionMs)
        else httpsUri != null && nativeLoadWithSessionCache(handle, next, httpsUri, options.decoderMode.ordinal,
            options.videoEffect.ordinal, options.playWhenReady, options.startPositionMs, cache.first, cache.second)
        if (!accepted) return rejected("load rejected; mailbox full or descriptor duplication failed")
        cancelCapture()
        bufferEpoch = 0
        bufferTrackingDisabled = false
        activeSubtitleChangeId = 0
        sessionCacheGeneration = if (cache != null) next else null
        mutableSessionCacheRanges.value = null
        mutableSessionCacheStatus.value = if (cache != null)
            SessionCacheStatus(next, SessionCacheStatus.Phase.PREPARING) else null
        mutableBufferedRange.value = null
        mutableSubtitlePositionNotice.value = null
        mutableState.value = PlaybackSnapshot(generation = next, phase = PlaybackPhase.PREPARING,
            volume = mutableState.value.volume, muted = mutableState.value.muted)
        return CommandResult.Accepted
    }

    fun command(kind: Int, value: Long = 0, scalar: Double = 0.0, endMs: Long = -1): CommandResult {
        checkMain()
        if (handle == 0L) return rejected("session closed")
        if (mutableState.value.pendingAudioTrack != null && kind in setOf(STEP, SEEK, RATE, LOOP, SCRUB_BEGIN))
            return rejected("audio track selection in progress")
        if (mutableState.value.pendingSubtitleTrack != null && kind in setOf(STEP, SEEK, RATE, LOOP, SCRUB_BEGIN))
            return rejected("subtitle selection in progress")
        if (mutableState.value.frameStep == FrameStepStatus.STEPPING && kind in setOf(STEP, PLAY, SEEK, RATE, LOOP, SCRUB_BEGIN))
            return rejected("frame step in progress")
        if (mutableState.value.scrub?.active == true && kind in setOf(STEP, PLAY, SEEK, RATE, LOOP))
            return rejected("video scrub in progress")
        if (mutableState.value.scrub?.status == ScrubStatus.TIMED_OUT && kind in setOf(PLAY, SEEK, RATE, LOOP, STEP))
            return CommandResult.Rejected(PlaybackFailure(PlaybackErrorCode.SCRUB_TIMEOUT,
                "change position or reload after scrub timeout"))
        val changesTimeline = kind in setOf(STOP, SEEK, LOOP, STEP, SCRUB_BEGIN, SCRUB_TO, SCRUB_END, SCRUB_CANCEL) ||
            kind == PLAY && mutableState.value.frameStep == FrameStepStatus.END_OF_MEDIA
        val epoch = if (changesTimeline) nextBufferEpoch() else null
        val accepted = if (changesTimeline && epoch != null)
            nativeTimelineCommand(handle, kind, value, scalar, endMs, epoch)
        else nativeCommand(handle, kind, value, scalar, endMs)
        if (!accepted) return rejected("native mailbox full or invalid command")
        if (changesTimeline) invalidateBufferedRange(epoch)
        if (kind == STOP) {
            sessionCacheGeneration = null
            mutableSessionCacheStatus.value = null
            mutableSessionCacheRanges.value = null
            cancelCapture()
        }
        // Synchronous admission prevents two clicks before native's acknowledgment arrives.
        if (kind == STEP) mutableState.value = mutableState.value.copy(frameStep = FrameStepStatus.STEPPING, framePositionNs = null)
        return CommandResult.Accepted
    }

    fun beginScrub(): CommandResult {
        checkMain()
        if (nextScrubId == Long.MAX_VALUE) return rejected("scrub operation ids exhausted")
        val id = ++nextScrubId
        val initial = mutableState.value.positionMs.coerceIn(0, ((mutableState.value.durationMs ?: 1) - 1).coerceAtLeast(0))
        val result = command(SCRUB_BEGIN, value = initial, endMs = id)
        if (result is CommandResult.Accepted) {
            val state = mutableState.value
            val timedOut = state.scrub?.takeIf { it.status == ScrubStatus.TIMED_OUT }
            scrubRevision = 0
            mutableState.value = state.copy(
                scrub = if (timedOut != null) timedOut.copy(id = id)
                    else VideoScrub(id, ScrubStatus.DRAGGING, initial),
                frameStep = FrameStepStatus.IDLE, framePositionNs = null,
                failure = if (timedOut != null) state.failure else null)
        }
        return result
    }

    fun selectAudio(track: AudioTrack): CommandResult {
        checkMain()
        val current = mutableState.value
        fun unavailable() = CommandResult.Rejected(PlaybackFailure(PlaybackErrorCode.AUDIO_TRACK_UNAVAILABLE,
            "track must belong to prepared current media with no pending timeline operation"))
        if (handle == 0L || current.generation != track.generation || track !in current.audioTracks ||
            current.phase !in setOf(PlaybackPhase.PLAYING, PlaybackPhase.PAUSED, PlaybackPhase.BUFFERING) ||
            current.pendingAudioTrack != null || current.scrub?.active == true || current.scrub?.status == ScrubStatus.TIMED_OUT ||
            current.frameStep == FrameStepStatus.STEPPING || nextAudioChangeId == Long.MAX_VALUE) return unavailable()
        val id = ++nextAudioChangeId
        val epoch = nextBufferEpoch()
        val accepted = if (epoch != null) nativeSelectAudioWithEpoch(handle, track.generation, id, track.index, epoch)
            else nativeSelectAudio(handle, track.generation, id, track.index)
        if (!accepted) return unavailable()
        invalidateBufferedRange(epoch)
        mutableState.value = current.copy(pendingAudioTrack = AudioTrackChange(id, track.index), failure = null)
        return CommandResult.Accepted
    }

    fun selectSubtitle(track: SubtitleTrack?): CommandResult {
        checkMain()
        val current = mutableState.value
        fun unavailable() = CommandResult.Rejected(PlaybackFailure(PlaybackErrorCode.SUBTITLE_UNAVAILABLE,
            "subtitle requires prepared current media without an active selection, drag or step"))
        if (handle == 0L || current.phase !in setOf(PlaybackPhase.PLAYING, PlaybackPhase.PAUSED, PlaybackPhase.BUFFERING) ||
            (track != null && (track.generation != current.generation || track !in current.subtitleTracks)) ||
            current.pendingSubtitleTrack != null || current.scrub?.active == true || current.scrub?.status == ScrubStatus.TIMED_OUT ||
            current.frameStep == FrameStepStatus.STEPPING || nextSubtitleChangeId == Long.MAX_VALUE) return unavailable()
        val id = ++nextSubtitleChangeId
        if (!nativeSelectSubtitle(handle, current.generation, id, track?.index ?: -1)) return unavailable()
        activeSubtitleChangeId = id
        mutableSubtitlePositionNotice.value = null
        mutableState.value = current.copy(pendingSubtitleTrack = SubtitleTrackChange(id, track?.index),
            subtitleCue = null, failure = null)
        return CommandResult.Accepted
    }

    fun addSubtitle(document: SrtSubtitle, generation: Long): CommandResult {
        checkMain()
        val current = mutableState.value
        fun unavailable() = CommandResult.Rejected(PlaybackFailure(PlaybackErrorCode.SUBTITLE_UNAVAILABLE,
            "SRT requires the same prepared source without a pending subtitle, drag or step"))
        if (handle == 0L || generation != current.generation || current.phase !in setOf(
                PlaybackPhase.PLAYING, PlaybackPhase.PAUSED, PlaybackPhase.BUFFERING) ||
            current.pendingSubtitleTrack != null || current.scrub?.active == true || current.scrub?.status == ScrubStatus.TIMED_OUT ||
            current.frameStep == FrameStepStatus.STEPPING || nextSubtitleChangeId == Long.MAX_VALUE) return unavailable()
        val id = ++nextSubtitleChangeId
        if (!nativeAddSubtitle(handle, generation, id, document.title.toByteArray(Charsets.UTF_8), document.payload)) return unavailable()
        activeSubtitleChangeId = id
        mutableSubtitlePositionNotice.value = null
        mutableState.value = current.copy(pendingSubtitleTrack = SubtitleTrackChange(id, 64), failure = null)
        return CommandResult.Accepted
    }

    fun updateScrub(positionMs: Long, final: Boolean): CommandResult {
        checkMain()
        val current = mutableState.value.scrub?.takeIf { it.status in setOf(ScrubStatus.DRAGGING, ScrubStatus.TIMED_OUT) }
            ?: return rejected("no active drag")
        val duration = mutableState.value.durationMs?.takeIf { it > 0 } ?: return rejected("unknown duration")
        val target = positionMs.coerceIn(0, duration - 1)
        if (current.status == ScrubStatus.TIMED_OUT && target == current.requestedPositionMs)
            return CommandResult.Rejected(PlaybackFailure(PlaybackErrorCode.SCRUB_TIMEOUT, "change position to retry"))
        val revision = if (target != current.requestedPositionMs) scrubRevision + 1 else scrubRevision
        if (revision > 9_007_199_254_740_991L) return rejected("scrub target revisions exhausted")
        val result = command(if (final) SCRUB_END else SCRUB_TO, target, revision.toDouble(), current.id)
        if (result is CommandResult.Accepted) {
            scrubRevision = revision
            mutableState.value = mutableState.value.copy(scrub = current.copy(
                requestedPositionMs = target, status = if (final) ScrubStatus.SETTLING else ScrubStatus.DRAGGING), failure = null)
        }
        return result
    }

    fun cancelScrub(): CommandResult {
        checkMain()
        val current = mutableState.value.scrub?.takeIf { it.active } ?: return rejected("no active drag")
        val result = command(SCRUB_CANCEL, endMs = current.id)
        if (result is CommandResult.Accepted) mutableState.value = mutableState.value.copy(
            scrub = current.copy(status = ScrubStatus.SETTLING))
        return result
    }

    fun surface(surface: Surface?): CommandResult {
        checkMain()
        if (handle == 0L) return rejected("session closed")
        val epoch = nextBufferEpoch()
        val accepted = if (epoch != null) nativeSurfaceWithEpoch(handle, surface, epoch) else nativeSurface(handle, surface)
        return if (accepted) {
            invalidateBufferedRange(epoch)
            surfaceAvailable = surface != null
            cancelCapture()
            CommandResult.Accepted
        } else rejected("surface command rejected")
    }

    fun close() {
        checkMain()
        if (handle == 0L) return
        cancelCapture()
        mutableBufferedRange.value = null
        mutableSessionCacheRanges.value = null
        mutableSubtitlePositionNotice.value = null
        sessionCacheGeneration = null
        mutableSessionCacheStatus.value = null
        bufferTrackingDisabled = true
        surfaceAvailable = false
        val closing = handle
        handle = 0
        synchronized(eventLock) {
            handler.removeCallbacksAndMessages(callbackToken)
            pendingEvents.clear()
            deliveryScheduled = false
        }
        mutableState.value = mutableState.value.copy(phase = PlaybackPhase.RELEASING,
            subtitleTracks = emptyList(), selectedSubtitleTrackIndex = null, pendingSubtitleTrack = null, subtitleCue = null,
            frameStep = FrameStepStatus.IDLE, framePositionNs = null, scrub = null,
            audioTracks = emptyList(), selectedAudioTrackIndex = null, pendingAudioTrack = null)
        // Release has a reserved mailbox path. Never joins a native worker on the UI thread.
        nativeRelease(closing)
    }

    suspend fun awaitReleased() = released.await()

    /** Called from native threads; events are low-frequency state/diagnostics, never per-pixel frames. */
    @Suppress("unused")
    private fun onNativeEvent(generation: Long, event: Int, first: Long, second: Long, detail: String) {
        if (event !in 1..25) return
        synchronized(eventLock) {
            if (generation > pendingGeneration) {
                pendingGeneration = generation
                pendingEvents.clear()
            } else if (generation < pendingGeneration && event != EVENT_RELEASED) return
            // Moving the entry to the end preserves the order of the latest phase/error facts.
            pendingEvents.remove(event)
            pendingEvents[event] = NativeEvent(generation, event, first, second, detail)
            if (!deliveryScheduled) {
                deliveryScheduled = true
                handler.postAtTime(::deliverEvents, callbackToken, SystemClock.uptimeMillis())
            }
        }
    }

    private fun deliverEvents() {
        val events = synchronized(eventLock) {
            deliveryScheduled = false
            pendingEvents.values.toList().also { pendingEvents.clear() }
        }
        for (event in events) {
            val old = mutableState.value
            if (event.kind == EVENT_RELEASED) {
                mutableSubtitlePositionNotice.value = null
                mutableState.value = NativeEvents.reduce(old, event.generation, event.kind, event.first, event.second, event.detail)
                released.complete(Unit)
                continue
            }
            if (handle == 0L || event.generation != old.generation) continue
            if (event.kind == 22) {
                if (!bufferTrackingDisabled && surfaceAvailable && old.scrub?.active != true &&
                    old.phase !in setOf(PlaybackPhase.IDLE, PlaybackPhase.ENDED, PlaybackPhase.FAILED,
                        PlaybackPhase.RELEASING, PlaybackPhase.RELEASED))
                    mutableBufferedRange.value = NativeBufferedRanges.reduce(mutableBufferedRange.value,
                        old.generation, event.generation, bufferEpoch, event.detail, event.first, event.second)
                continue
            }
            if (event.kind == 23) {
                if (!bufferTrackingDisabled && surfaceAvailable && old.pendingSubtitleTrack == null &&
                    old.phase in setOf(PlaybackPhase.PLAYING, PlaybackPhase.PAUSED, PlaybackPhase.BUFFERING)) {
                    when (val change = NativeSubtitles.positionNoticeChange(event.detail, bufferEpoch,
                        activeSubtitleChangeId, old.selectedSubtitleTrackIndex, event.first, event.second)) {
                        NativeSubtitles.PositionNoticeChange.Clear -> mutableSubtitlePositionNotice.value = null
                        is NativeSubtitles.PositionNoticeChange.Unconfirmed -> mutableSubtitlePositionNotice.value =
                            SubtitlePositionNotice(event.generation, change.trackIndex, change.framePositionNs)
                        null -> Unit
                    }
                }
                continue
            }
            if (event.kind == 24) {
                if (sessionCacheGeneration == event.generation && old.phase !in setOf(
                        PlaybackPhase.IDLE, PlaybackPhase.ENDED, PlaybackPhase.FAILED,
                        PlaybackPhase.RELEASING, PlaybackPhase.RELEASED)) {
                    mutableSessionCacheStatus.value = when (event.first) {
                        1L -> SessionCacheStatus(event.generation, SessionCacheStatus.Phase.ATTACHED)
                        2L -> SessionCacheStatus(event.generation, SessionCacheStatus.Phase.FALLBACK,
                            SessionCacheStatus.FallbackReason.fromNative(event.second))
                        else -> mutableSessionCacheStatus.value
                    }
                    if (event.first == 2L) mutableSessionCacheRanges.value = null
                }
                continue
            }
            if (event.kind == 25) {
                if (sessionCacheGeneration == event.generation &&
                    mutableSessionCacheStatus.value?.phase == SessionCacheStatus.Phase.ATTACHED &&
                    old.phase !in setOf(PlaybackPhase.IDLE, PlaybackPhase.ENDED, PlaybackPhase.FAILED,
                        PlaybackPhase.RELEASING, PlaybackPhase.RELEASED)) {
                    mutableSessionCacheRanges.value = NativeCacheRanges.snapshot(event.generation, event.detail)
                }
                continue
            }
            val detail = if (event.kind == 21) {
                if (bufferTrackingDisabled) continue
                NativeSubtitles.currentCuePayload(event.detail, bufferEpoch, activeSubtitleChangeId) ?: continue
            } else event.detail
            mutableState.value = NativeEvents.reduce(old, event.generation, event.kind, event.first, event.second, detail,
                expectedScrubRevision = scrubRevision)
            val selectedSubtitle = mutableState.value.selectedSubtitleTrackIndex
            if (selectedSubtitle == null || selectedSubtitle !in 0..63 ||
                mutableState.value.pendingSubtitleTrack != null) mutableSubtitlePositionNotice.value = null
            if (mutableState.value.phase in setOf(PlaybackPhase.IDLE, PlaybackPhase.ENDED, PlaybackPhase.FAILED)) {
                sessionCacheGeneration = null
                mutableSessionCacheStatus.value = null
                mutableSessionCacheRanges.value = null
                mutableBufferedRange.value = null
                mutableSubtitlePositionNotice.value = null
                cancelCapture()
            }
        }
    }

    private fun checkMain() = check(Looper.myLooper() == Looper.getMainLooper()) { "Playback commands require the main thread" }
    private fun nextBufferEpoch(): Long? = if (bufferEpoch == Long.MAX_VALUE) null else bufferEpoch + 1
    private fun invalidateBufferedRange(epoch: Long?) {
        mutableSubtitlePositionNotice.value = null
        if (epoch == null) {
            bufferTrackingDisabled = true
            mutableState.value = mutableState.value.copy(subtitleCue = null)
        } else bufferEpoch = epoch
        mutableBufferedRange.value = null
    }
    private fun rejected(detail: String) = CommandResult.Rejected(PlaybackFailure(PlaybackErrorCode.COMMAND_REJECTED, detail))

    private external fun nativeCreate(): Long
    private external fun nativeStartRecording(handle: Long, generation: Long, fd: Int, width: Int, height: Int, encoder: String): Long
    private external fun nativeFinishRecording(handle: Long, lease: Long, cancel: Boolean): Boolean
    private external fun nativeCapture(handle: Long, generation: Long, id: Long): Boolean
    private external fun nativeCancelCapture(handle: Long, id: Long)
    private external fun nativeLoad(handle: Long, generation: Long, fd: Int, uri: String?, test: Boolean,
        mode: Int, effect: Int, play: Boolean, positionMs: Long): Boolean
    private external fun nativeLoadWithSessionCache(handle: Long, generation: Long, uri: String, mode: Int,
        effect: Int, play: Boolean, positionMs: Long, directory: String, capacityBytes: Long): Boolean
    private external fun nativeCommand(handle: Long, kind: Int, value: Long, scalar: Double, endMs: Long): Boolean
    private external fun nativeTimelineCommand(handle: Long, kind: Int, value: Long, scalar: Double, endMs: Long, epoch: Long): Boolean
    private external fun nativeSurface(handle: Long, surface: Surface?): Boolean
    private external fun nativeSurfaceWithEpoch(handle: Long, surface: Surface?, epoch: Long): Boolean
    private external fun nativeSelectAudio(handle: Long, generation: Long, id: Long, index: Int): Boolean
    private external fun nativeSelectAudioWithEpoch(handle: Long, generation: Long, id: Long, index: Int, epoch: Long): Boolean
    private external fun nativeSelectSubtitle(handle: Long, generation: Long, id: Long, index: Int): Boolean
    private external fun nativeAddSubtitle(handle: Long, generation: Long, id: Long, title: ByteArray, payload: ByteArray): Boolean
    private external fun nativeRelease(handle: Long)

    companion object {
        const val PLAY = 1
        const val PAUSE = 2
        const val STOP = 3
        const val SEEK = 4
        const val RATE = 5
        const val VOLUME = 6
        const val EFFECT = 9
        const val MUTE = 10
        const val LOOP = 11
        const val STEP = 12
        const val SCRUB_BEGIN = 13
        const val SCRUB_TO = 14
        const val SCRUB_END = 15
        const val SCRUB_CANCEL = 16
        private const val EVENT_RELEASED = 10
    }
}
