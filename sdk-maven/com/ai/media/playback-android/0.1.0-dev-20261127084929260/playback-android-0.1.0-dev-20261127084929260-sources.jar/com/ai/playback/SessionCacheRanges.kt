package com.ai.playback

/** A confirmed half-open interval on the media timeline, in milliseconds. */
data class SessionCacheRange(val startPositionMs: Long, val endPositionMs: Long)

/** A conservative snapshot for one source generation; intervals are ordered and disjoint. */
data class SessionCacheRanges(val generation: Long, val ranges: List<SessionCacheRange>)
