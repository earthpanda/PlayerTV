package com.ai.playback.internal.export

import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import com.ai.playback.ClipExportError
import com.ai.playback.ClipExportRequest
import com.ai.playback.VideoEffect
import java.io.FileDescriptor

internal class ClipVideoPipeline(input: FileDescriptor, track: Int, format: MediaFormat,
    request: ClipExportRequest, videoEffect: VideoEffect, muxer: ClipMuxer, checkCancelled: ()->Unit) : AutoCloseable {
    private var encoder: MediaCodec?=null
    private var decoder: ClipDecoder?=null
    private var gl: ClipGlRenderer?=null
    private val encoded: EncodedOutput
    private val info=MediaCodec.BufferInfo()
    private val startUs=request.startPositionMs*1000
    private val endUs=request.endPositionMs*1000
    private var decoderDone=false
    private var signalled=false
    val width=format.intOr("crop-right",format.getInteger(MediaFormat.KEY_WIDTH)-1)-format.intOr("crop-left",0)+1
    val height=format.intOr("crop-bottom",format.getInteger(MediaFormat.KEY_HEIGHT)-1)-format.intOr("crop-top",0)+1
    val done: Boolean get() = encoded.done
    var firstUs=-1L; private set
    var lastUs=-1L; private set
    var positionUs=startUs; private set
    val decoderName: String get() = requireNotNull(decoder).codec.name
    val encoderName: String get() = requireNotNull(encoder).name
    init {
        try {
            val mime=format.getString(MediaFormat.KEY_MIME)
            val profile=format.intOr(MediaFormat.KEY_PROFILE,0)
            if(mime !in setOf("video/avc","video/hevc","video/x-vnd.on2.vp8","video/x-vnd.on2.vp9") ||
                width<=0 || height<=0 || width%2!=0 || height%2!=0 || width.toLong()*height>3840L*2160 ||
                format.intOr("sar-width",1)!=format.intOr("sar-height",1) ||
                format.intOr(MediaFormat.KEY_COLOR_TRANSFER,0) in setOf(MediaFormat.COLOR_TRANSFER_ST2084,MediaFormat.COLOR_TRANSFER_HLG) ||
                (mime=="video/avc" && profile==MediaCodecInfo.CodecProfileLevel.AVCProfileHigh10) ||
                (mime=="video/hevc" && profile!=0 && profile!=MediaCodecInfo.CodecProfileLevel.HEVCProfileMain) ||
                (mime=="video/x-vnd.on2.vp9" && profile!=0 && profile!=MediaCodecInfo.CodecProfileLevel.VP9Profile0))
                fail(ClipExportError.UNSUPPORTED_SOURCE)
            val fps=format.intOr(MediaFormat.KEY_FRAME_RATE,30).coerceAtLeast(1)
            val bitrate=format.intOr(MediaFormat.KEY_BIT_RATE,
                (width.toLong()*height*fps/6).coerceIn(1_000_000,40_000_000).toInt()).coerceAtLeast(256_000)
            val target=MediaFormat.createVideoFormat("video/avc",width,height).apply {
                setInteger(MediaFormat.KEY_COLOR_FORMAT,MediaCodecInfo.CodecCapabilities.COLOR_FormatSurface)
                setInteger(MediaFormat.KEY_BIT_RATE,bitrate)
                setInteger(MediaFormat.KEY_FRAME_RATE,fps)
                setInteger(MediaFormat.KEY_I_FRAME_INTERVAL,1)
                setInteger(MediaFormat.KEY_PROFILE,MediaCodecInfo.CodecProfileLevel.AVCProfileBaseline)
                // An absent source tag must not leave RGB->YUV conversion and the encoded VUI
                // to unrelated vendor defaults (measured BT.601 pixels tagged SMPTE-240M).
                setInteger(MediaFormat.KEY_COLOR_STANDARD,format.intOr(MediaFormat.KEY_COLOR_STANDARD,
                    if(width>=1280 || height>=720) MediaFormat.COLOR_STANDARD_BT709 else MediaFormat.COLOR_STANDARD_BT601_NTSC))
                setInteger(MediaFormat.KEY_COLOR_RANGE,format.intOr(MediaFormat.KEY_COLOR_RANGE,MediaFormat.COLOR_RANGE_LIMITED))
                setInteger(MediaFormat.KEY_COLOR_TRANSFER,format.intOr(MediaFormat.KEY_COLOR_TRANSFER,MediaFormat.COLOR_TRANSFER_SDR_VIDEO))
            }
            val codec=configuredHardwareCodec(target,true); encoder=codec
            gl=ClipGlRenderer(codec.createInputSurface(),width,height,videoEffect,checkCancelled)
            codec.start(); encoded=EncodedOutput(codec,muxer,true)
            decoder=ClipDecoder(input,track,startUs,true,requireNotNull(gl).decoderSurface)
        } catch(error: Throwable) {
            try { close() } catch(cleanup: Throwable) { error.addSuppressed(cleanup) }; throw error
        }
    }
    fun tick(): Boolean {
        var active=encoded.drain()
        if(done || encoded.blocked) return active
        val codec=requireNotNull(decoder).codec
        if(!decoderDone) {
            active=requireNotNull(decoder).feed() || active
            val index=codec.dequeueOutputBuffer(info,0)
            if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) return true
            if(index>=0) {
                active=true
                val pts=info.presentationTimeUs
                val render=info.size>0 && pts>=startUs && pts<endUs
                codec.releaseOutputBuffer(index,render)
                if(render) {
                    if(lastUs>=0 && pts<=lastUs) fail(ClipExportError.CODEC_FAILED)
                    // Display the first included picture at clip start, including silent sources.
                    // Later pictures retain A-relative timing; never rebase the whole video track.
                    requireNotNull(gl).draw(if(firstUs<0) 0 else pts-startUs)
                    if(firstUs<0) firstUs=pts
                    lastUs=pts; positionUs=pts
                }
                // Decoder output is in presentation order. Feed references beyond B until this
                // point; stopping compressed input at a B-frame's PTS could drop earlier pictures.
                if((info.size>0 && pts>=endUs) || info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM!=0) {
                    decoderDone=true; positionUs=endUs
                }
            }
        }
        if(decoderDone && !signalled) {
            requireNotNull(encoder).signalEndOfInputStream(); signalled=true; active=true
        }
        return active
    }
    override fun close() = closeAll({ decoder?.close(); decoder=null },{ releaseCodec(encoder); encoder=null },{ gl?.close(); gl=null })
}
