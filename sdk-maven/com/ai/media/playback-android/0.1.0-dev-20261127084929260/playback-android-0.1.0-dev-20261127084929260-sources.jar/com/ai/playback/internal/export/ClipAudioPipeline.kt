package com.ai.playback.internal.export

import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaCodecInfo
import android.media.MediaFormat
import com.ai.playback.ClipExportError
import com.ai.playback.ClipExportRequest
import java.io.FileDescriptor

/** One held decoded PCM block; copies only its in-range samples into the AAC encoder. */
internal class ClipAudioPipeline(input: FileDescriptor, track: Int, format: MediaFormat,
    request: ClipExportRequest, muxer: ClipMuxer) : AutoCloseable {
    private val rate=format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
    private val channels=format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
    private val frameBytes=channels*2
    private val startUs=request.startPositionMs*1000
    private val endUs=request.endPositionMs*1000
    private var decoder: ClipDecoder?=null
    private var encoder: MediaCodec?=null
    private val encoded: EncodedOutput
    private val info=MediaCodec.BufferInfo()
    private var pcmIndex=-1
    private var pcmFirst=0
    private var pcmEnd=0
    private var finishAfterPcm=false
    private var decoderDone=false
    private var encoderInputEnded=false
    var positionUs=startUs; private set
    val done: Boolean get() = encoded.done
    init {
        try {
            if(rate !in 8000..48000 || channels !in 1..2) fail(ClipExportError.UNSUPPORTED_SOURCE)
            val target=MediaFormat.createAudioFormat("audio/mp4a-latm",rate,channels).apply {
                setInteger(MediaFormat.KEY_AAC_PROFILE,MediaCodecInfo.CodecProfileLevel.AACObjectLC)
                setInteger(MediaFormat.KEY_BIT_RATE,if(channels==1) 96000 else 192000)
                setInteger(MediaFormat.KEY_MAX_INPUT_SIZE,16384)
            }
            val codec=MediaCodec.createEncoderByType("audio/mp4a-latm"); encoder=codec
            codec.configure(target,null,null,MediaCodec.CONFIGURE_FLAG_ENCODE); codec.start()
            encoded=EncodedOutput(codec,muxer,false)
            decoder=ClipDecoder(input,track,startUs,false)
        } catch(error: Throwable) {
            try { close() } catch(cleanup: Throwable) { error.addSuppressed(cleanup) }; throw error
        }
    }
    fun tick(): Boolean {
        var active=encoded.drain()
        if(done || encoded.blocked) return active
        val source=requireNotNull(decoder).codec
        val target=requireNotNull(encoder)
        if(pcmIndex<0 && !decoderDone) {
            active=requireNotNull(decoder).feed() || active
            val index=source.dequeueOutputBuffer(info,0)
            if(index==MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                val output=source.outputFormat
                if(output.getInteger(MediaFormat.KEY_SAMPLE_RATE)!=rate || output.getInteger(MediaFormat.KEY_CHANNEL_COUNT)!=channels ||
                    output.intOr(MediaFormat.KEY_PCM_ENCODING,AudioFormat.ENCODING_PCM_16BIT)!=AudioFormat.ENCODING_PCM_16BIT)
                    fail(ClipExportError.UNSUPPORTED_SOURCE)
                return true
            }
            if(index>=0) {
                active=true
                if(info.size%frameBytes!=0) { source.releaseOutputBuffer(index,false); fail(ClipExportError.CODEC_FAILED) }
                val frames=info.size/frameBytes
                pcmFirst=sampleCeiling(startUs-info.presentationTimeUs).coerceIn(0,frames.toLong()).toInt()
                pcmEnd=sampleCeiling(endUs-info.presentationTimeUs).coerceIn(0,frames.toLong()).toInt()
                finishAfterPcm=info.presentationTimeUs+frames*1_000_000L/rate>=endUs ||
                    info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM!=0
                pcmIndex=index
                if(pcmFirst>=pcmEnd) releasePcm()
            }
        }
        if(pcmIndex>=0) {
            val index=target.dequeueInputBuffer(0)
            if(index>=0) {
                val output=requireNotNull(target.getInputBuffer(index)); output.clear()
                val count=minOf(pcmEnd-pcmFirst,output.capacity()/frameBytes)
                if(count<=0) fail(ClipExportError.CODEC_FAILED)
                val input=requireNotNull(source.getOutputBuffer(pcmIndex)).duplicate().apply {
                    position(info.offset+pcmFirst*frameBytes); limit(info.offset+(pcmFirst+count)*frameBytes)
                }
                output.put(input)
                val pts=info.presentationTimeUs+pcmFirst*1_000_000L/rate-startUs
                target.queueInputBuffer(index,0,count*frameBytes,pts.coerceAtLeast(0),0)
                pcmFirst+=count; active=true
                positionUs=(info.presentationTimeUs+pcmFirst*1_000_000L/rate).coerceAtMost(endUs)
                if(pcmFirst>=pcmEnd) releasePcm()
            }
        }
        if(decoderDone && pcmIndex<0 && !encoderInputEnded) {
            val index=target.dequeueInputBuffer(0)
            if(index>=0) {
                target.queueInputBuffer(index,0,0,endUs-startUs,MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                encoderInputEnded=true; positionUs=endUs; active=true
            }
        }
        return active
    }
    private fun sampleCeiling(deltaUs: Long) = if(deltaUs<=0) 0 else (deltaUs*rate+999999)/1_000_000
    private fun releasePcm() {
        requireNotNull(decoder).codec.releaseOutputBuffer(pcmIndex,false); pcmIndex=-1
        if(finishAfterPcm) decoderDone=true
    }
    override fun close() = closeAll({ decoder?.close(); decoder=null },{ releaseCodec(encoder); encoder=null })
}
