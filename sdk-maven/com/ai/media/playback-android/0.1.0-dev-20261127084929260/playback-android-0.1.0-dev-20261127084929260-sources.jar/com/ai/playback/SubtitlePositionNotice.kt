package com.ai.playback

/**
 * The selected embedded subtitle cannot currently be confirmed for this output frame.
 * This is nonfatal: playback and later subtitles may continue normally. A null notice
 * means there is no current notice; it does not prove that a subtitle exists or is absent.
 */
data class SubtitlePositionNotice(
    val generation: Long,
    val trackIndex: Int,
    val framePositionNs: Long,
)
