package com.ai.playback

import android.os.ParcelFileDescriptor
import android.system.Os
import android.system.OsConstants
import com.ai.playback.internal.export.ClipTranscoder
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.asCoroutineDispatcher
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.withContext
import java.util.concurrent.Executors

/** Audio index is the ordinal among the source's audio tracks; null explicitly omits audio.
 * expectedAudioTrackCount rejects a different source/catalog instead of selecting another track.
 */
data class ClipExportRequest(val startPositionMs: Long, val endPositionMs: Long,
    val audioTrackIndex: Int? = null, val expectedAudioTrackCount: Int? = null)

data class ClipExportResult(val width: Int, val height: Int, val videoFrames: Long,
    val firstVideoPositionUs: Long, val lastVideoPositionUs: Long,
    val videoDecoder: String, val videoEncoder: String)

enum class ClipExportError { BUSY, INVALID_RANGE, INVALID_FILE, UNSUPPORTED_SOURCE,
    UNSUPPORTED_CODEC, NO_FRAMES, TIMED_OUT, CODEC_FAILED, OUTPUT_FAILED }

class ClipExportException(val code: ClipExportError, cause: Throwable? = null) :
    Exception("Clip export: " + code, cause)

/** Independent 1x SDR H.264/AAC MP4 export, with no inherited playback or subtitle state.
 * One confined worker owns codec/EGL, including across suspending progress callbacks.
 * No video CPU readback/software fallback. One process-wide task, no queue/retries.
 * Callers keep both complete, regular descriptors open until return; output must be new and empty.
 * Duplicates are task-owned; failures leave partial output for the caller's task-owned cleanup.
 * Progress is a suspending worker callback, at most 5 Hz; return promptly and marshal UI as needed.
 * Cancellation propagates only after owned codec/EGL/muxer resources have been released.
 */
object VideoClipExporter {
    private val admission = Mutex()

    suspend fun export(source: ParcelFileDescriptor, output: ParcelFileDescriptor, request: ClipExportRequest,
        onProgress: suspend (Int) -> Unit = {}): ClipExportResult =
        export(source, output, request, VideoEffect.NONE, onProgress)

    /** Immutable task effect, applied on GPU before hardware encoding. The original overload
     * remains NONE; changing a player's video effect cannot affect this independent task.
     */
    suspend fun export(source: ParcelFileDescriptor, output: ParcelFileDescriptor, request: ClipExportRequest,
        videoEffect: VideoEffect,
        onProgress: suspend (Int) -> Unit = {}): ClipExportResult {
        if (!admission.tryLock()) throw ClipExportException(ClipExportError.BUSY)
        try {
            return Executors.newSingleThreadExecutor { task -> Thread(task, "ClipExport") }
                .asCoroutineDispatcher().use { worker -> withContext(worker) {
                ensureActive()
                if (request.startPositionMs < 0 || request.endPositionMs <= request.startPositionMs ||
                    request.endPositionMs > Long.MAX_VALUE / 1000)
                    throw ClipExportException(ClipExportError.INVALID_RANGE)
                val sourceStat = Os.fstat(source.fileDescriptor)
                val outputStat = Os.fstat(output.fileDescriptor)
                if (!OsConstants.S_ISREG(sourceStat.st_mode) || !OsConstants.S_ISREG(outputStat.st_mode) ||
                    outputStat.st_size != 0L || (sourceStat.st_dev == outputStat.st_dev && sourceStat.st_ino == outputStat.st_ino))
                    throw ClipExportException(ClipExportError.INVALID_FILE)
                ParcelFileDescriptor.dup(source.fileDescriptor).use { inputCopy ->
                    ParcelFileDescriptor.dup(output.fileDescriptor).use { outputCopy ->
                        val context = currentCoroutineContext()
                        ClipTranscoder(inputCopy.fileDescriptor, outputCopy.fileDescriptor, request, videoEffect) {
                            context.ensureActive()
                        }.use { it.run(onProgress) }
                    }
                }
            } }
        } catch (cancelled: CancellationException) {
            throw cancelled
        } catch (known: ClipExportException) {
            throw known
        } catch (error: android.media.MediaCodec.CodecException) {
            throw ClipExportException(ClipExportError.CODEC_FAILED, error)
        } catch (error: Exception) {
            throw ClipExportException(ClipExportError.OUTPUT_FAILED, error)
        } finally {
            admission.unlock()
        }
    }
}
