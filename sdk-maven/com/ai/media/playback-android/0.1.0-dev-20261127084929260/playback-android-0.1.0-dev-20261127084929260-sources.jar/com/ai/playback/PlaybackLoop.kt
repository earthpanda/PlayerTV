package com.ai.playback

/** Current-source interval [startMs, endMs). At least 500ms prevents accidental tiny seek loops.
 * Millisecond values must fit GStreamer's signed nanosecond timeline. No persistence is implied.
 */
data class PlaybackLoop(val startMs: Long, val endMs: Long, val wholeVideo: Boolean = false) {
    init {
        require(startMs >= 0 && endMs <= Long.MAX_VALUE / 1_000_000 &&
            endMs > startMs && endMs - startMs >= MIN_DURATION_MS) { "invalid A-B interval" }
    }

    companion object { const val MIN_DURATION_MS = 500L }
}
