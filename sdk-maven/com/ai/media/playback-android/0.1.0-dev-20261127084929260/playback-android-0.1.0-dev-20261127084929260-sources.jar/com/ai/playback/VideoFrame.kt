package com.ai.playback

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.os.Looper
import java.nio.ByteBuffer

enum class FrameCaptureError { NO_FRAME, BUSY, TOO_LARGE, UNSUPPORTED_FORMAT, READBACK_FAILED, ALLOCATION_FAILED, TIMED_OUT }

class FrameCaptureException(val code: FrameCaptureError) : Exception("Frame capture: $code")

/** An owned, bounded copy of one post-filter video frame, without subtitles/UI/crop or letterboxing.
 * Pixels are not retained by the player. Keep only as long as needed; toBitmap() allocates a
 * caller-owned Bitmap which must be recycled. Non-square pixels retain the coded raster/PAR.
 */
class VideoFrame internal constructor(
    val generation: Long,
    val positionNs: Long,
    private val sourceWidth: Int,
    private val sourceHeight: Int,
    metadata: String,
    private val rgba: ByteArray,
) {
    private val fields = metadata.split('\t').also { require(it.size == 9) }
    private val orientation = fields[2].toInt()
    private val swapsAxes = orientation in setOf(1, 3, 6, 7)
    val width: Int = if (swapsAxes) sourceHeight else sourceWidth
    val height: Int = if (swapsAxes) sourceWidth else sourceHeight
    val pixelAspectRatioNumerator: Int = fields[if (swapsAxes) 1 else 0].toInt()
    val pixelAspectRatioDenominator: Int = fields[if (swapsAxes) 0 else 1].toInt()

    init {
        require(sourceWidth > 0 && sourceHeight > 0 && positionNs >= 0 && orientation in 0..7)
        require(sourceWidth.toLong() * sourceHeight * 4 == rgba.size.toLong() && rgba.size <= 32 * 1024 * 1024)
        require(fields.size == 9 && pixelAspectRatioNumerator > 0 && pixelAspectRatioDenominator > 0)
    }

    /** Worker thread only. Applies the sample's GL placement and display rotation/mirror, retaining
     * original pixel resolution. ReadPixels rows already follow GStreamer's top-row texture convention;
     * an unconditional vertical flip would invert ordinary files. */
    fun toBitmap(): Bitmap {
        check(Looper.myLooper() != Looper.getMainLooper()) { "Convert video pixels off the main thread" }
        return try { convertBitmap() } catch (memory: OutOfMemoryError) {
            throw FrameCaptureException(FrameCaptureError.ALLOCATION_FAILED).apply { initCause(memory) }
        }
    }

    private fun convertBitmap(): Bitmap {
        val raw = Bitmap.createBitmap(sourceWidth, sourceHeight, Bitmap.Config.ARGB_8888)
        try {
            raw.copyPixelsFromBuffer(ByteBuffer.wrap(rgba))
            val affine = fields.drop(3).map(String::toFloat)
            require(affine.all(Float::isFinite))
            if (orientation == 0 && affine == listOf(1f, 0f, 0f, 1f, 0f, 0f)) return raw
            val src = floatArrayOf(0f, 0f, sourceWidth.toFloat(), 0f,
                sourceWidth.toFloat(), sourceHeight.toFloat(), 0f, sourceHeight.toFloat())
            val dst = FloatArray(8)
            for (i in 0..3) {
                val x = 2 * src[i * 2] / sourceWidth - 1
                val y = 1 - 2 * src[i * 2 + 1] / sourceHeight
                val nx = affine[0] * x + affine[2] * y + affine[4]
                val ny = affine[1] * x + affine[3] * y + affine[5]
                val (rx, ry) = when (orientation) {
                    1 -> ny to -nx
                    2 -> -nx to -ny
                    3 -> -ny to nx
                    4 -> -nx to ny
                    5 -> nx to -ny
                    6 -> -ny to -nx
                    7 -> ny to nx
                    else -> nx to ny
                }
                dst[i * 2] = (rx + 1) * width / 2
                dst[i * 2 + 1] = (1 - ry) * height / 2
            }
            val transform = Matrix()
            require(transform.setPolyToPoly(src, 0, dst, 0, 4)) { "Invalid frame transform" }
            val upright = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            try {
                upright.eraseColor(Color.BLACK)
                Canvas(upright).drawBitmap(raw, transform, null)
                return upright
            } catch (error: Throwable) {
                upright.recycle()
                throw error
            } finally { raw.recycle() }
        } catch (error: Throwable) {
            if (!raw.isRecycled) raw.recycle()
            throw error
        }
    }
}
